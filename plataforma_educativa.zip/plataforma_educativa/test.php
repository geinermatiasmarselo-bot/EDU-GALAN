<?php
include 'includes/conexion.php';

// Verificar conexión
echo "✅ Conexión exitosa.<br>";

// Verificar existencia de tabla usuarios
$result = mysqli_query($conexion, "SHOW TABLES LIKE 'usuarios'");
if (mysqli_num_rows($result) > 0) {
    echo "✅ Tabla 'usuarios' existe.<br>";
} else {
    echo "❌ Tabla 'usuarios' NO existe.<br>";
}

// Verificar admin
$sql = "SELECT id, nombre, email, password FROM usuarios WHERE email='admin@galan.edu.co'";
$res = mysqli_query($conexion, $sql);
if ($admin = mysqli_fetch_assoc($res)) {
    echo "✅ Administrador encontrado: " . $admin['nombre'] . "<br>";
    // Probar contraseña
    if (password_verify('admin123', $admin['password'])) {
        echo "✅ La contraseña 'admin123' es válida.<br>";
    } else {
        echo "❌ La contraseña NO coincide con el hash almacenado.<br>";
    }
} else {
    echo "❌ Administrador NO encontrado.<br>";
}
?>