<?php
include 'conexion.php';

$grado = $_GET['grado'];
$sql = "SELECT id, nombre FROM materias WHERE grado='$grado' ORDER BY nombre";
$resultado = mysqli_query($conexion, $sql);

$materias = [];
while ($m = mysqli_fetch_assoc($resultado)) {
    $materias[] = $m;
}

header('Content-Type: application/json');
echo json_encode($materias);
?>