<?php
if (!isset($_SESSION['id'])) return;
$rol_asistente = $_SESSION['rol'];
$nombre_asistente = $_SESSION['nombre'];
?>

<div id="asistente-btn" onclick="toggleAsistente()" title="Abrir asistente">
    <div id="asistente-cara">🎓</div>
</div>

<div id="asistente-ventana" style="display:none;">
    <div id="asistente-header">
        <div class="d-flex align-items-center gap-2">
            <span style="font-size:1.5rem;">🎓</span>
            <div>
                <strong>Asistente Galán</strong>
                <div style="font-size:0.75rem; opacity:0.8;">¿En qué te puedo ayudar?</div>
            </div>
        </div>
        <button onclick="toggleAsistente()" style="background:none;border:none;color:white;font-size:1.2rem;cursor:pointer;">✕</button>
    </div>

    <div id="asistente-mensajes">
        <div class="msg-bot">
            👋 ¡Hola <strong><?= $nombre_asistente ?>!</strong> Soy el asistente del Colegio José Antonio Galán.
            <br><br>Puedes preguntarme sobre:
            <br><br>
            <?php if ($rol_asistente == 'profesor'): ?>
                📊 <b>notas</b> — cómo registrarlas<br>
                ✅ <b>asistencia</b> — cómo tomarla<br>
                📋 <b>formativos</b> — cómo registrarlos<br>
                📁 <b>actividades</b> — cómo subirlas<br>
                👤 <b>perfil</b> — ver perfil del estudiante
            <?php else: ?>
                📊 <b>notas</b> — cómo verlas<br>
                ✅ <b>asistencia</b> — cómo verla<br>
                📋 <b>formativos</b> — qué son<br>
                📁 <b>actividades</b> — cómo entregar<br>
                🔔 <b>notificaciones</b> — cómo funcionan
            <?php endif; ?>
        </div>
    </div>

    <div id="asistente-input">
        <input type="text" id="asistente-pregunta"
               placeholder="Escribe tu pregunta..."
               onkeypress="if(event.key==='Enter') enviarPregunta()">
        <button onclick="enviarPregunta()">➤</button>
    </div>
</div>

<style>
#asistente-btn {
    position: fixed;
    bottom: 30px;
    right: 30px;
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, #2563eb, #1d4ed8);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: 0 8px 25px rgba(37,99,235,0.4);
    z-index: 9999;
    transition: all 0.3s;
    animation: bounce 3s ease-in-out infinite;
}
#asistente-btn:hover { transform: scale(1.1); }
#asistente-cara { font-size: 1.8rem; }

@keyframes bounce {
    0%,100% { transform: translateY(0); }
    50%      { transform: translateY(-8px); }
}

#asistente-ventana {
    position: fixed;
    bottom: 100px;
    right: 30px;
    width: 350px;
    height: 480px;
    background: white;
    border-radius: 20px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.2);
    z-index: 9998;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    animation: slideUpChat 0.3s ease-out;
}

@keyframes slideUpChat {
    from { opacity:0; transform: translateY(20px) scale(0.95); }
    to   { opacity:1; transform: translateY(0) scale(1); }
}

#asistente-header {
    background: linear-gradient(135deg, #2563eb, #1d4ed8);
    color: white;
    padding: 16px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

#asistente-mensajes {
    flex: 1;
    overflow-y: auto;
    padding: 16px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    background: #f8fafc;
}

.msg-bot {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 14px 14px 14px 4px;
    padding: 12px 16px;
    font-size: 0.875rem;
    line-height: 1.6;
    max-width: 92%;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    animation: msgIn 0.3s ease-out;
}

.msg-user {
    background: linear-gradient(135deg, #2563eb, #1d4ed8);
    color: white;
    border-radius: 14px 14px 4px 14px;
    padding: 12px 16px;
    font-size: 0.875rem;
    line-height: 1.6;
    max-width: 92%;
    align-self: flex-end;
    box-shadow: 0 2px 8px rgba(37,99,235,0.3);
    animation: msgIn 0.3s ease-out;
}

@keyframes msgIn {
    from { opacity:0; transform: translateY(8px); }
    to   { opacity:1; transform: translateY(0); }
}

#asistente-input {
    padding: 12px 16px;
    border-top: 1px solid #e2e8f0;
    display: flex;
    gap: 8px;
    background: white;
}

#asistente-pregunta {
    flex: 1;
    border: 1.5px solid #e2e8f0;
    border-radius: 10px;
    padding: 10px 14px;
    font-size: 0.875rem;
    outline: none;
    transition: border-color 0.2s;
    font-family: 'Inter', sans-serif;
}

#asistente-pregunta:focus { border-color: #2563eb; }

#asistente-input button {
    background: linear-gradient(135deg, #2563eb, #1d4ed8);
    color: white;
    border: none;
    border-radius: 10px;
    padding: 10px 16px;
    cursor: pointer;
    font-size: 1rem;
    transition: all 0.2s;
}

#asistente-input button:hover { transform: scale(1.05); }
</style>

<script>
const rolUsuario = '<?= $rol_asistente ?>';

const respuestasProfesor = {
    'notas': '📊 <b>Cómo registrar notas:</b><br>1. Ve al módulo <b>Notas</b> desde tu panel<br>2. Filtra por grado<br>3. Selecciona el estudiante<br>4. Elige la materia (solo tus materias)<br>5. Ingresa la nota y el periodo<br>6. Clic en <b>Guardar Nota</b>',
    'asistencia': '✅ <b>Cómo tomar asistencia:</b><br>1. Ve al módulo <b>Asistencia</b><br>2. Selecciona el grado y la fecha<br>3. Marca cada estudiante como:<br>&nbsp;&nbsp;&nbsp;✅ Presente<br>&nbsp;&nbsp;&nbsp;❌ Ausente<br>&nbsp;&nbsp;&nbsp;⏰ Tardanza<br>4. Clic en <b>Guardar Asistencia</b>',
    'formativos': '📋 <b>Cómo registrar formativos:</b><br>1. Ve al módulo <b>Formativos</b><br>2. Selecciona el grado y el estudiante<br>3. Elige el tipo:<br>&nbsp;&nbsp;&nbsp;⚠️ Llamado escrito<br>&nbsp;&nbsp;&nbsp;👨‍👩‍👧 Citación a padres<br>&nbsp;&nbsp;&nbsp;🚫 Suspensión<br>4. Describe el motivo<br>5. Clic en <b>Guardar Formativo</b>',
    'actividades': '📁 <b>Cómo subir actividades:</b><br>1. Ve al módulo <b>Actividades</b><br>2. Clic en pestaña <b>Publicar Actividad</b><br>3. Escribe el título y descripción<br>4. Selecciona la materia<br>5. Pon la fecha límite<br>6. Adjunta un archivo (opcional)<br>7. Clic en <b>Publicar</b>',
    'perfil': '👤 <b>Ver perfil del estudiante:</b><br>1. Ve al módulo <b>Notas</b><br>2. En la tabla de notas busca el estudiante<br>3. Clic en el botón <b>Ver perfil</b><br>4. Verás sus datos, notas y formativos',
    'entregas': '📬 <b>Cómo calificar entregas:</b><br>1. Ve al módulo <b>Actividades</b><br>2. Clic en <b>Mis Actividades</b><br>3. Clic en <b>Ver entregas</b> de la actividad<br>4. Ingresa la nota y clic en ✔',
};

const respuestasEstudiante = {
    'notas': '📊 <b>Cómo ver tus notas:</b><br>1. Ve a <b>Mis Notas</b> desde tu panel<br>2. Tienes dos vistas:<br>&nbsp;&nbsp;&nbsp;📅 <b>Por Periodo</b> — notas de cada periodo<br>&nbsp;&nbsp;&nbsp;📚 <b>Por Materia</b> — notas de cada materia<br>3. También ves tu promedio general arriba',
    'asistencia': '✅ <b>Cómo ver tu asistencia:</b><br>1. Ve a <b>Mi Asistencia</b> desde tu panel<br>2. Verás tarjetas con:<br>&nbsp;&nbsp;&nbsp;📅 Total de días<br>&nbsp;&nbsp;&nbsp;✅ Presentes<br>&nbsp;&nbsp;&nbsp;❌ Ausentes<br>&nbsp;&nbsp;&nbsp;⏰ Tardanzas<br>3. Filtra por mes para ver el detalle',
    'formativos': '📋 <b>Qué son los formativos:</b><br>Son anotaciones que registra tu profesor sobre tu comportamiento:<br>&nbsp;&nbsp;&nbsp;⚠️ Llamado escrito<br>&nbsp;&nbsp;&nbsp;👨‍👩‍👧 Citación a padres<br>&nbsp;&nbsp;&nbsp;🚫 Suspensión<br><br>Puedes verlos en <b>Mis Formativos</b> desde tu panel',
    'actividades': '📁 <b>Cómo entregar actividades:</b><br>1. Ve a <b>Actividades</b> desde tu panel<br>2. Selecciona la pestaña de la materia<br>3. Busca la actividad pendiente 📤<br>4. Adjunta tu archivo (PDF, Word o imagen)<br>5. Clic en <b>Entregar</b><br><br>⚠️ Si ya venció no podrás entregar',
    'notificaciones': '🔔 <b>Cómo funcionan las notificaciones:</b><br>Recibes notificaciones automáticas cuando:<br>&nbsp;&nbsp;&nbsp;📊 Tu profesor registra una nota<br>&nbsp;&nbsp;&nbsp;📁 Se publica una nueva actividad<br>&nbsp;&nbsp;&nbsp;⏰ Una actividad está por vencer<br><br>El número rojo en el 🔔 del menú indica cuántas tienes sin leer',
    'perfil': '👤 <b>Tu perfil:</b><br>Tu información personal está registrada en el sistema incluyendo:<br>&nbsp;&nbsp;&nbsp;📱 Tu teléfono<br>&nbsp;&nbsp;&nbsp;🏠 Tu dirección<br>&nbsp;&nbsp;&nbsp;👨‍👩‍👧 Datos de tus acudientes<br><br>Si hay algún error contacta a tu profesor',
};

function buscarRespuesta(pregunta) {
    const p = pregunta.toLowerCase();
    const respuestas = rolUsuario === 'profesor' ? respuestasProfesor : respuestasEstudiante;

    if (p.includes('nota') || p.includes('calificacion') || p.includes('calificación')) return respuestas['notas'];
    if (p.includes('asistencia') || p.includes('falta') || p.includes('presente') || p.includes('ausente')) return respuestas['asistencia'];
    if (p.includes('formativo') || p.includes('llamado') || p.includes('citacion') || p.includes('citación') || p.includes('suspension') || p.includes('suspensión')) return respuestas['formativos'];
    if (p.includes('actividad') || p.includes('tarea') || p.includes('entregar') || p.includes('entrega') || p.includes('subir')) return respuestas['actividades'];
    if (p.includes('notificacion') || p.includes('notificación') || p.includes('alerta') || p.includes('aviso')) return respuestas['notificaciones'] || null;
    if (p.includes('perfil') || p.includes('estudiante') || p.includes('datos')) return respuestas['perfil'];

    return '🤔 No entendí tu pregunta. Puedes preguntarme sobre:<br><br>' +
        (rolUsuario === 'profesor'
            ? '📊 <b>notas</b> · ✅ <b>asistencia</b> · 📋 <b>formativos</b> · 📁 <b>actividades</b> · 👤 <b>perfil</b>'
            : '📊 <b>notas</b> · ✅ <b>asistencia</b> · 📋 <b>formativos</b> · 📁 <b>actividades</b> · 🔔 <b>notificaciones</b>');
}

function toggleAsistente() {
    const ventana = document.getElementById('asistente-ventana');
    const btn = document.getElementById('asistente-btn');
    if (ventana.style.display === 'none') {
        ventana.style.display = 'flex';
        btn.style.animation = 'none';
        document.getElementById('asistente-pregunta').focus();
    } else {
        ventana.style.display = 'none';
        btn.style.animation = 'bounce 3s ease-in-out infinite';
    }
}

function enviarPregunta() {
    const input = document.getElementById('asistente-pregunta');
    const pregunta = input.value.trim();
    if (!pregunta) return;

    const mensajes = document.getElementById('asistente-mensajes');

    // Mensaje usuario
    mensajes.innerHTML += `<div class="msg-user">${pregunta}</div>`;
    input.value = '';
    mensajes.scrollTop = mensajes.scrollHeight;

    // Simular delay de respuesta
    setTimeout(() => {
        const respuesta = buscarRespuesta(pregunta);
        mensajes.innerHTML += `<div class="msg-bot">${respuesta}</div>`;
        mensajes.scrollTop = mensajes.scrollHeight;
    }, 600);
}
</script>