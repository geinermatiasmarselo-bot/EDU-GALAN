<?php
$host = "localhost";
$usuario = "root";
$password = "";          // Si tu MySQL tiene contraseña, cámbiala aquí
$base_datos = "plataforma_educativa";

$conexion = mysqli_connect($host, $usuario, $password, $base_datos);

if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Establecer conjunto de caracteres UTF-8
mysqli_set_charset($conexion, "utf8mb4");
?>