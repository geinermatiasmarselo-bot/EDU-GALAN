<?php
session_start();
include '../includes/conexion.php';

if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'estudiante') {
    header("Location: ../index.php");
    exit();
}

$estudiante_id = $_SESSION['id'];
$mensaje = "";
$error = "";

// Datos del estudiante
$sql_est = "SELECT * FROM usuarios WHERE id=$estudiante_id";
$res_est = mysqli_query($conexion, $sql_est);
$estudiante = mysqli_fetch_assoc($res_est);

// Entregar actividad
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $actividad_id = $_POST['actividad_id'];
    $archivo = "";

    $verificar = "SELECT id FROM entregas WHERE actividad_id=$actividad_id AND estudiante_id=$estudiante_id";
    $res_ver = mysqli_query($conexion, $verificar);

    if (mysqli_num_rows($res_ver) > 0) {
        $error = "❌ Ya entregaste esta actividad";
    } else {
        if (isset($_FILES['archivo']) && $_FILES['archivo']['error'] == 0) {
            $ext = pathinfo($_FILES['archivo']['name'], PATHINFO_EXTENSION);
            $permitidos = ['pdf', 'docx', 'jpg', 'jpeg', 'png'];
            if (in_array(strtolower($ext), $permitidos)) {
                $nombre_archivo = time() . '_' . $estudiante_id . '_' . $_FILES['archivo']['name'];
                $ruta = "../uploads/entregas/" . $nombre_archivo;
                move_uploaded_file($_FILES['archivo']['tmp_name'], $ruta);
                $archivo = $nombre_archivo;

                $sql_act = "SELECT fecha_limite FROM actividades WHERE id=$actividad_id";
                $res_act = mysqli_query($conexion, $sql_act);
                $act = mysqli_fetch_assoc($res_act);
                $estado = strtotime($act['fecha_limite']) < time() ? 'tarde' : 'entregado';

                $sql = "INSERT INTO entregas (actividad_id, estudiante_id, archivo, estado) 
                        VALUES ($actividad_id, $estudiante_id, '$archivo', '$estado')";
                if (mysqli_query($conexion, $sql)) {
                    $mensaje = "✅ Actividad entregada correctamente";
                } else {
                    $error = "❌ Error al entregar";
                }
            } else {
                $error = "❌ Tipo de archivo no permitido";
            }
        } else {
            $error = "❌ Debes adjuntar un archivo";
        }
    }
}

// Obtener actividades agrupadas por materia
$sql_actividades = "SELECT a.*, m.nombre as materia, m.id as materia_id_real,
                    (SELECT id FROM entregas WHERE actividad_id=a.id AND estudiante_id=$estudiante_id) as entrega_id,
                    (SELECT estado FROM entregas WHERE actividad_id=a.id AND estudiante_id=$estudiante_id) as estado_entrega,
                    (SELECT calificacion FROM entregas WHERE actividad_id=a.id AND estudiante_id=$estudiante_id) as calificacion
                    FROM actividades a
                    JOIN materias m ON a.materia_id = m.id
                    WHERE m.grado='{$estudiante['grado']}'
                    ORDER BY m.nombre, a.fecha_limite ASC";
$res_actividades = mysqli_query($conexion, $sql_actividades);

$actividades_por_materia = [];
while ($a = mysqli_fetch_assoc($res_actividades)) {
    $actividades_por_materia[$a['materia']][] = $a;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Actividades</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<nav class="navbar navbar-dark bg-success">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="estudiante.php">
            <img src="../assets/logo.png" alt="Logo"> Colegio José Antonio Galán
        </a>
        <div class="ms-auto d-flex gap-2">
            <a href="estudiante.php" class="btn btn-outline-light btn-sm">⬅ Volver</a>
            <a href="../cerrar_sesion.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-4">

    <!-- Info estudiante -->
    <div class="card shadow-sm mb-4 border-0">
        <div class="card-body d-flex align-items-center gap-3">
            <div class="fs-1">👤</div>
            <div>
                <h4 class="mb-0 fw-bold"><?= $estudiante['nombre'] ?></h4>
                <span class="badge bg-success"><?= $estudiante['grado'] ?></span>
            </div>
        </div>
    </div>

    <h4 class="fw-bold mb-4">📁 Mis Actividades</h4>

    <?php if ($mensaje): ?>
        <div class="alert alert-success"><?= $mensaje ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <?php if (empty($actividades_por_materia)): ?>
        <div class="alert alert-info">📭 No hay actividades publicadas aún.</div>
    <?php else: ?>

    <!-- Tabs por materia -->
    <ul class="nav nav-tabs mb-4" id="tabsMaterias">
        <?php $primero = true; foreach ($actividades_por_materia as $materia => $actividades): 
            // Contar pendientes
            $pendientes = count(array_filter($actividades, fn($a) => !$a['entrega_id'] && strtotime($a['fecha_limite']) >= time()));
        ?>
            <li class="nav-item">
                <a class="nav-link <?= $primero ? 'active' : '' ?>"
                   data-bs-toggle="tab"
                   href="#mat_<?= preg_replace('/\s+/', '_', $materia) ?>">
                    📚 <?= $materia ?>
                    <?php if ($pendientes > 0): ?>
                        <span class="badge bg-danger ms-1"><?= $pendientes ?></span>
                    <?php endif; ?>
                </a>
            </li>
        <?php $primero = false; endforeach; ?>
    </ul>

    <div class="tab-content">
        <?php $primero = true; foreach ($actividades_por_materia as $materia => $actividades): ?>
            <div class="tab-pane fade <?= $primero ? 'show active' : '' ?>"
                 id="mat_<?= preg_replace('/\s+/', '_', $materia) ?>">

                <?php foreach ($actividades as $a):
                    $vencida = strtotime($a['fecha_limite']) < time();
                    $entregada = $a['entrega_id'] != null;
                ?>
                <div class="card shadow-sm mb-3 border-0">
                    <div class="card-header d-flex justify-content-between align-items-center
                        <?= $entregada ? 'bg-success' : ($vencida ? 'bg-danger' : 'bg-info') ?> text-white">
                        <strong>📁 <?= $a['titulo'] ?></strong>
                        <span class="badge bg-white <?= $entregada ? 'text-success' : ($vencida ? 'text-danger' : 'text-info') ?>">
                            <?php if ($entregada): ?>
                                ✅ Entregada
                            <?php elseif ($vencida): ?>
                                ⏰ Vencida
                            <?php else: ?>
                                📤 Pendiente
                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="card-body">
                        <p class="mb-1"><?= $a['descripcion'] ?></p>
                        <small class="text-muted">
                            📅 Límite: <?= date('d/m/Y', strtotime($a['fecha_limite'])) ?>
                        </small>

                        <?php if ($a['archivo']): ?>
                            <br>
                            <a href="../uploads/actividades/<?= $a['archivo'] ?>"
                               target="_blank" class="btn btn-sm btn-outline-info mt-2">
                                📎 Ver actividad
                            </a>
                        <?php endif; ?>

                        <?php if ($entregada): ?>
                            <div class="mt-2">
                                <?php if ($a['calificacion']): ?>
                                    <span class="badge fs-6 <?= $a['calificacion'] >= 6 ? 'bg-success' : 'bg-danger' ?>">
                                        Nota: <?= $a['calificacion'] ?>
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">⏳ Sin calificar</span>
                                <?php endif; ?>
                            </div>
                        <?php elseif (!$vencida): ?>
                            <form method="POST" enctype="multipart/form-data" class="mt-3">
                                <input type="hidden" name="actividad_id" value="<?= $a['id'] ?>">
                                <div class="d-flex gap-2 align-items-center">
                                    <input type="file" name="archivo" class="form-control form-control-sm"
                                           accept=".pdf,.docx,.jpg,.jpeg,.png" required>
                                    <button type="submit" class="btn btn-sm btn-success">
                                        📤 Entregar
                                    </button>
                                </div>
                                <small class="text-muted">PDF, Word o imágenes</small>
                            </form>
                        <?php else: ?>
                            <div class="alert alert-danger mt-2 mb-0 py-1">
                                ❌ No entregaste a tiempo
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>

            </div>
        <?php $primero = false; endforeach; ?>
    </div>

    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>