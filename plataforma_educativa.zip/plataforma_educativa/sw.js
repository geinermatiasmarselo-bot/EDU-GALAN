const CACHE_NAME = 'galan-v1';
const urlsToCache = [
    '/plataforma_educativa/index.php',
    '/plataforma_educativa/css/estilos.css',
    '/plataforma_educativa/assets/logo.png',
    'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css',
    'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap'
];

// Instalar Service Worker
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME).then(cache => {
            console.log('Cache abierto');
            return cache.addAll(urlsToCache);
        })
    );
});

// Activar Service Worker
self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.filter(name => name !== CACHE_NAME)
                          .map(name => caches.delete(name))
            );
        })
    );
});

// Interceptar requests
self.addEventListener('fetch', event => {
    event.respondWith(
        caches.match(event.request).then(response => {
            // Si está en caché lo devuelve, si no hace fetch
            if (response) return response;
            return fetch(event.request).catch(() => {
                // Si no hay conexión muestra página offline
                return caches.match('/plataforma_educativa/index.php');
            });
        })
    );
});