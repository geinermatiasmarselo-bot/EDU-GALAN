<?php
include 'includes/conexion.php';
$pass = password_hash('admin123', PASSWORD_DEFAULT);
$sql = "UPDATE usuarios SET password='$pass' WHERE rol='administrador'";
mysqli_query($conexion, $sql);
echo "✅ Contraseña actualizada correctamente";
?>