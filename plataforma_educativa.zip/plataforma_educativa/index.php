<?php
session_start();
include 'includes/conexion.php';

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM usuarios WHERE email = '$email'";
    $resultado = mysqli_query($conexion, $sql);
    $usuario = mysqli_fetch_assoc($resultado);

    if ($usuario && password_verify($password, $usuario['password'])) {
        $_SESSION['id'] = $usuario['id'];
        $_SESSION['nombre'] = $usuario['nombre'];
        $_SESSION['rol'] = $usuario['rol'];

        if ($usuario['rol'] == 'administrador') {
            header("Location: dashboard/admin.php");
        } else if ($usuario['rol'] == 'profesor') {
            header("Location: dashboard/profesor.php");
        } else {
            header("Location: dashboard/estudiante.php");
        }
        exit();
    } else {
        $error = "Correo o contraseña incorrectos";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Colegio José Antonio Galán — Iniciar Sesión</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/estilos.css">

    <!-- PWA -->
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#2563eb">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="Galán">
    <link rel="apple-touch-icon" href="assets/logo.png">
</head>
<body class="bg-login d-flex align-items-center justify-content-center min-vh-100">

    <div class="card shadow-lg p-4" style="width: 420px;">
        <div class="text-center mb-4">
            <img src="assets/logo.png" class="logo-login" alt="Logo Colegio">
            <h5 class="fw-bold text-primary mt-2">Colegio Cooperativo Técnico Industrial</h5>
            <h6 class="fw-semibold text-secondary">José Antonio Galán</h6>
            <p class="text-muted small mt-1">Inicia sesión para continuar</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label class="form-label fw-semibold">Correo electrónico</label>
                <input type="email" name="email" class="form-control"
                       placeholder="tucorreo@email.com" required>
            </div>
            <div class="mb-4">
                <label class="form-label fw-semibold">Contraseña</label>
                <input type="password" name="password" class="form-control"
                       placeholder="••••••••" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Ingresar</button>
        </form>

        <div class="text-center mt-3">
            <a href="registro.php" class="text-decoration-none text-muted small">
                ¿No tienes cuenta? <strong>Regístrate aquí</strong>
            </a>
            <br>
            <a href="recuperar_password.php" class="text-decoration-none text-muted small mt-1 d-block">
                ¿Olvidaste tu contraseña? <strong>Recupérala aquí</strong>
            </a>
        </div>
    </div>

<!-- PWA Service Worker -->
<script>
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/plataforma_educativa/sw.js')
            .then(reg => console.log('✅ SW registrado:', reg))
            .catch(err => console.log('❌ SW error:', err));
    });
}
</script>

</body>
</html>