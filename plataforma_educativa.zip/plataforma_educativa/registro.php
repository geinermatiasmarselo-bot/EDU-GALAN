<?php
session_start();
include 'includes/conexion.php';

$error = "";
$exito = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $rol = $_POST['rol'];
    $grado = isset($_POST['grado']) ? $_POST['grado'] : NULL;
    $tarjeta_identidad = isset($_POST['tarjeta_identidad']) ? $_POST['tarjeta_identidad'] : NULL;
    $telefono_estudiante = isset($_POST['telefono_estudiante']) ? $_POST['telefono_estudiante'] : NULL;
    $direccion = isset($_POST['direccion']) ? $_POST['direccion'] : NULL;
    $nombre_acudiente1 = isset($_POST['nombre_acudiente1']) ? $_POST['nombre_acudiente1'] : NULL;
    $telefono_acudiente1 = isset($_POST['telefono_acudiente1']) ? $_POST['telefono_acudiente1'] : NULL;
    $nombre_acudiente2 = isset($_POST['nombre_acudiente2']) ? $_POST['nombre_acudiente2'] : NULL;
    $telefono_acudiente2 = isset($_POST['telefono_acudiente2']) ? $_POST['telefono_acudiente2'] : NULL;

    $verificar = "SELECT * FROM usuarios WHERE email = '$email'";
    $resultado = mysqli_query($conexion, $verificar);

    if (mysqli_num_rows($resultado) > 0) {
        $error = "Este correo ya está registrado";
    } else {
        $sql = "INSERT INTO usuarios (nombre, email, password, rol, grado, tarjeta_identidad, 
                telefono_estudiante, direccion, nombre_acudiente1, telefono_acudiente1,
                nombre_acudiente2, telefono_acudiente2) 
                VALUES ('$nombre', '$email', '$password', '$rol', '$grado', '$tarjeta_identidad',
                '$telefono_estudiante', '$direccion', '$nombre_acudiente1', '$telefono_acudiente1',
                '$nombre_acudiente2', '$telefono_acudiente2')";

        if (mysqli_query($conexion, $sql)) {
            $nuevo_id = mysqli_insert_id($conexion);

            if ($rol == 'profesor' && isset($_POST['materias']) && count($_POST['materias']) > 0) {
                foreach ($_POST['materias'] as $materia_id) {
                    $sql_mat = "INSERT INTO profesor_materias (profesor_id, materia_id) VALUES ($nuevo_id, $materia_id)";
                    mysqli_query($conexion, $sql_mat);
                }
            }

            $exito = "¡Registro exitoso! Ya puedes iniciar sesión";
        } else {
            $error = "Error al registrar, intenta de nuevo";
        }
    }
}

// Obtener materias para profesores
$sql_materias = "SELECT * FROM materias ORDER BY grado, nombre";
$todas_materias = mysqli_query($conexion, $sql_materias);
$materias_por_grado = [];
while ($m = mysqli_fetch_assoc($todas_materias)) {
    $materias_por_grado[$m['grado']][] = $m;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - Colegio José Antonio Galán</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body class="bg-login d-flex align-items-center justify-content-center min-vh-100 py-5">

    <div class="card shadow-lg p-4" style="width: 550px;">
        <div class="text-center mb-4">
            <img src="assets/logo.png" class="logo-login" alt="Logo">
            <h5 class="fw-bold text-primary mt-2">Colegio Cooperativo Técnico Industrial</h5>
            <h6 class="fw-semibold text-secondary">José Antonio Galán</h6>
            <p class="text-muted small">Completa el formulario para registrarte</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        <?php if ($exito): ?>
            <div class="alert alert-success"><?= $exito ?></div>
        <?php endif; ?>

        <form method="POST">

            <!-- Datos básicos -->
            <h6 class="fw-bold text-primary mb-3">📋 Datos Básicos</h6>
            <div class="row g-3 mb-3">
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Nombre completo</label>
                    <input type="text" name="nombre" class="form-control" placeholder="Tu nombre completo" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Correo electrónico</label>
                    <input type="email" name="email" class="form-control" placeholder="tucorreo@email.com" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Contraseña</label>
                    <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Rol</label>
                    <select name="rol" id="rol" class="form-select" required onchange="toggleCampos()">
                        <option value="">Selecciona tu rol</option>
                        <option value="estudiante">Estudiante</option>
                        <option value="profesor">Profesor / Formativo</option>
                    </select>
                </div>
            </div>

            <!-- Campos solo estudiante -->
            <div id="campos_estudiante" style="display:none;">
                <hr>
                <h6 class="fw-bold text-primary mb-3">🎓 Datos del Estudiante</h6>
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Grado</label>
                        <select name="grado" id="grado" class="form-select">
                            <option value="">Selecciona tu grado</option>
                            <option value="Grado 6">Grado 6</option>
                            <option value="Grado 7">Grado 7</option>
                            <option value="Grado 8">Grado 8</option>
                            <option value="Grado 9">Grado 9</option>
                            <option value="Grado 10">Grado 10</option>
                            <option value="Grado 11">Grado 11</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Tarjeta de Identidad</label>
                        <input type="text" name="tarjeta_identidad" class="form-control" placeholder="Número de T.I.">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Teléfono del Estudiante</label>
                        <input type="text" name="telefono_estudiante" class="form-control" placeholder="Ej: 3001234567">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Dirección</label>
                        <input type="text" name="direccion" class="form-control" placeholder="Dirección de residencia">
                    </div>
                </div>

                <hr>
                <h6 class="fw-bold text-primary mb-3">👨‍👩‍👧 Acudiente 1</h6>
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Nombre del Acudiente</label>
                        <input type="text" name="nombre_acudiente1" class="form-control" placeholder="Nombre completo">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Teléfono del Acudiente</label>
                        <input type="text" name="telefono_acudiente1" class="form-control" placeholder="Ej: 3001234567">
                    </div>
                </div>

                <hr>
                <h6 class="fw-bold text-secondary mb-3">👨‍👩‍👧 Acudiente 2 <small class="text-muted">(opcional)</small></h6>
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Nombre del Acudiente</label>
                        <input type="text" name="nombre_acudiente2" class="form-control" placeholder="Nombre completo">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Teléfono del Acudiente</label>
                        <input type="text" name="telefono_acudiente2" class="form-control" placeholder="Ej: 3001234567">
                    </div>
                </div>
            </div>

            <!-- Campos solo profesor -->
            <div id="campos_profesor" style="display:none;">
                <hr>
                <h6 class="fw-bold text-primary mb-3">📚 Materias que dicta</h6>
                <p class="text-muted small">Puedes seleccionar varias materias de diferentes grados</p>
                <?php foreach ($materias_por_grado as $grado => $materias): ?>
                    <div class="mb-2">
                        <strong class="text-primary"><?= $grado ?></strong>
                        <div class="row mt-1">
                            <?php foreach ($materias as $m): ?>
                                <div class="col-6">
                                    <div class="form-check">
                                        <input type="checkbox" name="materias[]" value="<?= $m['id'] ?>"
                                               class="form-check-input" id="mat_<?= $m['id'] ?>">
                                        <label class="form-check-label small" for="mat_<?= $m['id'] ?>">
                                            <?= $m['nombre'] ?>
                                        </label>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <hr>
                <?php endforeach; ?>
            </div>

            <button type="submit" class="btn btn-primary w-100 mt-3">Registrarse</button>
        </form>

        <div class="text-center mt-3">
            <a href="index.php" class="text-decoration-none text-muted small">
                ¿Ya tienes cuenta? <strong>Inicia sesión</strong>
            </a>
        </div>
    </div>

<script>
function toggleCampos() {
    const rol = document.getElementById('rol').value;
    const camposEst = document.getElementById('campos_estudiante');
    const camposProf = document.getElementById('campos_profesor');
    const selectGrado = document.getElementById('grado');

    if (rol === 'estudiante') {
        camposEst.style.display = 'block';
        camposProf.style.display = 'none';
        selectGrado.required = true;
    } else if (rol === 'profesor') {
        camposEst.style.display = 'none';
        camposProf.style.display = 'block';
        selectGrado.required = false;
    } else {
        camposEst.style.display = 'none';
        camposProf.style.display = 'none';
        selectGrado.required = false;
    }
}
</script>

</body>
</html>