<?php
session_start();
include 'includes/conexion.php';

$mensaje = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    // Verificar si el correo existe
    $sql = "SELECT * FROM usuarios WHERE email='$email'";
    $res = mysqli_query($conexion, $sql);
    $usuario = mysqli_fetch_assoc($res);

    if (!$usuario) {
        $error = "❌ No existe una cuenta con ese correo";
    } else {
        // Verificar si ya tiene una solicitud pendiente
        $sql_check = "SELECT id FROM recuperacion_password WHERE usuario_id={$usuario['id']} AND estado='pendiente'";
        $res_check = mysqli_query($conexion, $sql_check);

        if (mysqli_num_rows($res_check) > 0) {
            $mensaje = "⏳ Ya tienes una solicitud pendiente. El administrador la atenderá pronto.";
        } else {
            // Crear solicitud
            $sql_rec = "INSERT INTO recuperacion_password (usuario_id) VALUES ({$usuario['id']})";
            mysqli_query($conexion, $sql_rec);

            // Notificar al administrador
            $sql_admin = "SELECT id FROM usuarios WHERE rol='administrador' LIMIT 1";
            $res_admin = mysqli_query($conexion, $sql_admin);
            $admin = mysqli_fetch_assoc($res_admin);

            if ($admin) {
                $titulo = "🔑 Solicitud de recuperación de contraseña";
                $msg_notif = "El usuario {$usuario['nombre']} ({$usuario['email']}) solicita cambio de contraseña";
                $sql_notif = "INSERT INTO notificaciones (usuario_id, titulo, mensaje, tipo) 
                              VALUES ({$admin['id']}, '$titulo', '$msg_notif', 'nota')";
                mysqli_query($conexion, $sql_notif);
            }

            $mensaje = "✅ Solicitud enviada. El administrador cambiará tu contraseña pronto.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Contraseña — José Antonio Galán</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body class="bg-login d-flex align-items-center justify-content-center min-vh-100">

    <div class="card shadow-lg p-4" style="width: 420px;">
        <div class="text-center mb-4">
            <img src="assets/logo.png" class="logo-login" alt="Logo">
            <h5 class="fw-bold text-primary mt-2">Recuperar Contraseña</h5>
            <p class="text-muted small">Ingresa tu correo y notificaremos al administrador</p>
        </div>

        <?php if ($mensaje): ?>
            <div class="alert alert-success"><?= $mensaje ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <?php if (!$mensaje): ?>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label fw-semibold">Correo electrónico</label>
                <input type="email" name="email" class="form-control"
                       placeholder="tucorreo@email.com" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">
                📤 Enviar solicitud
            </button>
        </form>
        <?php endif; ?>

        <div class="text-center mt-3">
            <a href="index.php" class="text-decoration-none text-muted small">
                ⬅ Volver al inicio de sesión
            </a>
        </div>
    </div>

</body>
</html>