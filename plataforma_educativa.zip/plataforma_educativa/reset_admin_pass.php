<?php
include 'includes/conexion.php';

$nueva_password = 'admin123';
$hash = password_hash($nueva_password, PASSWORD_DEFAULT);

$sql = "UPDATE usuarios SET password = '$hash' WHERE email = 'admin@galan.edu.co'";

if (mysqli_query($conexion, $sql)) {
    echo "✅ Contraseña del administrador actualizada correctamente.<br>";
    echo "Nuevo hash generado: " . $hash . "<br>";
    echo "<strong>Ahora puedes iniciar sesión con:</strong><br>";
    echo "Email: admin@galan.edu.co<br>";
    echo "Contraseña: admin123<br>";
    echo "<a href='index.php'>Ir al login</a>";
} else {
    echo "❌ Error al actualizar: " . mysqli_error($conexion);
}
?>