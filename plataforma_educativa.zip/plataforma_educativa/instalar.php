<?php
// instalar.php - Asistente de instalación de Plataforma Educativa Galán
session_start();

// Si ya existe el archivo de bloqueo, redirigir al index
if (file_exists('instalado.lock')) {
    header('Location: index.php');
    exit;
}

$step = $_GET['step'] ?? 1;
$error = '';
$success = '';

// Procesar configuración de base de datos (step 2)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $step == 2) {
    $host = $_POST['host'] ?? 'localhost';
    $user = $_POST['user'] ?? 'root';
    $pass = $_POST['pass'] ?? '';
    $dbname = $_POST['dbname'] ?? 'plataforma_educativa';

    // Probar conexión
    $conn = @mysqli_connect($host, $user, $pass);
    if (!$conn) {
        $error = 'No se pudo conectar a MySQL. Verifica host, usuario y contraseña.';
    } else {
        // Crear base de datos si no existe
        $sql = "CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
        if (!mysqli_query($conn, $sql)) {
            $error = 'Error al crear la base de datos: ' . mysqli_error($conn);
        } else {
            mysqli_select_db($conn, $dbname);

            // Cargar y ejecutar script SQL completo
            $sqlScript = file_get_contents('crear_bd.sql');
            if (!$sqlScript) {
                $error = 'No se encontró el archivo crear_bd.sql. Asegúrate de que esté en la raíz.';
            } else {
                // Ejecutar multi consulta
                if (mysqli_multi_query($conn, $sqlScript)) {
                    // Consumir resultados
                    do {
                        if ($result = mysqli_store_result($conn)) {
                            mysqli_free_result($result);
                        }
                    } while (mysqli_next_result($conn));

                    // Crear archivo de conexión
                    $conexionContent = "<?php\n";
                    $conexionContent .= "\$host = '$host';\n";
                    $conexionContent .= "\$usuario = '$user';\n";
                    $conexionContent .= "\$password = '$pass';\n";
                    $conexionContent .= "\$base_datos = '$dbname';\n\n";
                    $conexionContent .= "\$conexion = mysqli_connect(\$host, \$usuario, \$password, \$base_datos);\n";
                    $conexionContent .= "if (!\$conexion) {\n    die('Error de conexión: ' . mysqli_connect_error());\n}\n";
                    $conexionContent .= "?>";

                    if (file_put_contents('includes/conexion.php', $conexionContent)) {
                        $success = 'Base de datos configurada correctamente.';
                        // Redirigir a step 3 después de 2 segundos
                        header("Refresh:2; url=instalar.php?step=3");
                    } else {
                        $error = 'No se pudo escribir el archivo includes/conexion.php. Verifica permisos de escritura.';
                    }
                } else {
                    $error = 'Error al ejecutar script SQL: ' . mysqli_error($conn);
                }
            }
        }
        mysqli_close($conn);
    }
}

// Step 3: Configurar cuenta de administrador
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $step == 3) {
    include 'includes/conexion.php';

    $admin_email = $_POST['admin_email'] ?? 'admin@galan.edu.co';
    $admin_pass = $_POST['admin_pass'] ?? '';
    $admin_pass2 = $_POST['admin_pass2'] ?? '';

    if ($admin_pass !== $admin_pass2) {
        $error = 'Las contraseñas no coinciden.';
    } elseif (strlen($admin_pass) < 6) {
        $error = 'La contraseña debe tener al menos 6 caracteres.';
    } else {
        $hash = password_hash($admin_pass, PASSWORD_DEFAULT);
        // Actualizar admin existente o crear nuevo
        $check = mysqli_query($conexion, "SELECT id FROM usuarios WHERE email='$admin_email'");
        if (mysqli_num_rows($check) > 0) {
            $sql = "UPDATE usuarios SET password='$hash' WHERE email='$admin_email'";
        } else {
            $sql = "INSERT INTO usuarios (nombre, email, password, rol) VALUES ('Administrador', '$admin_email', '$hash', 'administrador')";
        }
        if (mysqli_query($conexion, $sql)) {
            // Insertar datos de ejemplo opcionales
            if (isset($_POST['demo_data'])) {
                // Materias básicas
                $materias = [
                    ['Matemáticas', 'Grado 6'], ['Lenguaje', 'Grado 6'], ['Ciencias', 'Grado 6'],
                    ['Matemáticas', 'Grado 7'], ['Lenguaje', 'Grado 7'], ['Ciencias', 'Grado 7']
                ];
                foreach ($materias as $m) {
                    mysqli_query($conexion, "INSERT IGNORE INTO materias (nombre, grado) VALUES ('{$m[0]}', '{$m[1]}')");
                }
                // Curso general
                mysqli_query($conexion, "INSERT IGNORE INTO cursos (id, nombre) VALUES (1, 'Curso General')");
            }
            // Crear archivo de bloqueo
            file_put_contents('instalado.lock', date('Y-m-d H:i:s'));
            $success = '¡Instalación completada! Redirigiendo al login...';
            header("Refresh:3; url=index.php");
        } else {
            $error = 'Error al configurar administrador: ' . mysqli_error($conexion);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalación - Plataforma Educativa Galán</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f1f5f9; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; font-family: 'Inter', sans-serif; }
        .installer-card { max-width: 600px; width: 100%; border-radius: 20px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); }
        .step-indicator { display: flex; justify-content: space-between; margin-bottom: 30px; }
        .step { text-align: center; flex: 1; }
        .step .circle { width: 35px; height: 35px; background: #e2e8f0; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 8px; font-weight: bold; }
        .step.active .circle { background: #2563eb; color: white; }
        .step.completed .circle { background: #16a34a; color: white; }
    </style>
</head>
<body>
<div class="installer-card card p-4">
    <div class="text-center mb-4">
        <img src="assets/logo.png" alt="Logo" style="width: 80px; height: 80px;">
        <h3 class="fw-bold mt-2">Instalación de Plataforma Educativa</h3>
        <p class="text-muted">Colegio José Antonio Galán</p>
    </div>

    <!-- Indicador de pasos -->
    <div class="step-indicator">
        <div class="step <?= $step >= 1 ? 'active' : '' ?> <?= $step > 1 ? 'completed' : '' ?>">
            <div class="circle">1</div>
            <small>Requisitos</small>
        </div>
        <div class="step <?= $step >= 2 ? 'active' : '' ?> <?= $step > 2 ? 'completed' : '' ?>">
            <div class="circle">2</div>
            <small>Base de Datos</small>
        </div>
        <div class="step <?= $step >= 3 ? 'active' : '' ?>">
            <div class="circle">3</div>
            <small>Admin</small>
        </div>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>

    <?php if ($step == 1): ?>
        <h5>Requisitos del servidor</h5>
        <ul class="list-group mb-3">
            <?php
            $php_version = phpversion();
            $php_ok = version_compare($php_version, '7.4', '>=');
            $mysql_ok = extension_loaded('mysqli');
            $gd_ok = extension_loaded('gd');
            $json_ok = extension_loaded('json');
            $session_ok = extension_loaded('session');
            ?>
            <li class="list-group-item d-flex justify-content-between">
                PHP >= 7.4
                <span><?= $php_ok ? '✅' : '❌' ?></span>
            </li>
            <li class="list-group-item d-flex justify-content-between">
                Extensión MySQLi
                <span><?= $mysql_ok ? '✅' : '❌' ?></span>
            </li>
            <li class="list-group-item d-flex justify-content-between">
                Extensión GD
                <span><?= $gd_ok ? '✅' : '❌' ?></span>
            </li>
            <li class="list-group-item d-flex justify-content-between">
                Extensión JSON
                <span><?= $json_ok ? '✅' : '❌' ?></span>
            </li>
            <li class="list-group-item d-flex justify-content-between">
                Soporte de sesiones
                <span><?= $session_ok ? '✅' : '❌' ?></span>
            </li>
        </ul>
        <?php if ($php_ok && $mysql_ok && $gd_ok && $json_ok && $session_ok): ?>
            <a href="instalar.php?step=2" class="btn btn-primary w-100">Continuar</a>
        <?php else: ?>
            <div class="alert alert-warning">Algunos requisitos no se cumplen. Asegúrate de tener PHP 7.4+ con las extensiones necesarias.</div>
        <?php endif; ?>

    <?php elseif ($step == 2): ?>
        <h5>Configuración de Base de Datos</h5>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Servidor MySQL</label>
                <input type="text" name="host" class="form-control" value="localhost" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Usuario</label>
                <input type="text" name="user" class="form-control" value="root" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Contraseña</label>
                <input type="password" name="pass" class="form-control" placeholder="(dejar vacío si no tiene)">
            </div>
            <div class="mb-3">
                <label class="form-label">Nombre de la base de datos</label>
                <input type="text" name="dbname" class="form-control" value="plataforma_educativa" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Probar conexión y crear tablas</button>
        </form>

    <?php elseif ($step == 3): ?>
        <h5>Configurar cuenta de Administrador</h5>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Correo electrónico del administrador</label>
                <input type="email" name="admin_email" class="form-control" value="admin@galan.edu.co" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Contraseña</label>
                <input type="password" name="admin_pass" class="form-control" required minlength="6">
            </div>
            <div class="mb-3">
                <label class="form-label">Confirmar contraseña</label>
                <input type="password" name="admin_pass2" class="form-control" required minlength="6">
            </div>
            <div class="form-check mb-3">
                <input type="checkbox" name="demo_data" class="form-check-input" id="demoCheck" checked>
                <label class="form-check-label" for="demoCheck">Insertar datos de ejemplo (materias básicas y curso general)</label>
            </div>
            <button type="submit" class="btn btn-success w-100">Completar instalación</button>
        </form>
    <?php endif; ?>

    <hr>
    <small class="text-muted text-center">Plataforma Educativa - Colegio José Antonio Galán</small>
</div>
</body>
</html>