CREATE DATABASE IF NOT EXISTS plataforma_educativa
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE plataforma_educativa;

CREATE TABLE IF NOT EXISTS usuarios (
  id                   INT AUTO_INCREMENT PRIMARY KEY,
  nombre               VARCHAR(150) NOT NULL,
  email                VARCHAR(150) NOT NULL UNIQUE,
  password             VARCHAR(255) NOT NULL,
  rol                  ENUM('estudiante','profesor','administrador') NOT NULL,
  grado                VARCHAR(20),
  tarjeta_identidad    VARCHAR(30),
  telefono_estudiante  VARCHAR(20),
  direccion            VARCHAR(255),
  nombre_acudiente1    VARCHAR(150),
  telefono_acudiente1  VARCHAR(20),
  nombre_acudiente2    VARCHAR(150),
  telefono_acudiente2  VARCHAR(20),
  created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS materias (
  id     INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  grado  VARCHAR(20) NOT NULL
);

CREATE TABLE IF NOT EXISTS cursos (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  nombre      VARCHAR(120) NOT NULL,
  descripcion TEXT,
  profesor_id INT,
  FOREIGN KEY (profesor_id) REFERENCES usuarios(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS profesor_materias (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  profesor_id INT NOT NULL,
  materia_id  INT NOT NULL,
  UNIQUE (profesor_id, materia_id),
  FOREIGN KEY (profesor_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (materia_id) REFERENCES materias(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS notas (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  estudiante_id INT NOT NULL,
  materia_id    INT NOT NULL,
  nota          DECIMAL(4,2) NOT NULL,
  periodo       VARCHAR(20) NOT NULL,
  observacion   TEXT,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (estudiante_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (materia_id) REFERENCES materias(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS asistencia (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  estudiante_id INT NOT NULL,
  curso_id      INT NOT NULL,
  fecha         DATE NOT NULL,
  estado        ENUM('presente','ausente','tardanza') NOT NULL,
  UNIQUE (estudiante_id, curso_id, fecha),
  FOREIGN KEY (estudiante_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (curso_id) REFERENCES cursos(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS formativos (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  estudiante_id INT NOT NULL,
  profesor_id   INT NOT NULL,
  tipo          ENUM('llamado_escrito','citacion_padres','suspension') NOT NULL,
  descripcion   TEXT,
  afecta_nota   DECIMAL(3,1) DEFAULT 0,
  firmado       ENUM('pendiente','firmado') DEFAULT 'pendiente',
  fecha         DATE NOT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (estudiante_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (profesor_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS actividades (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  profesor_id  INT NOT NULL,
  materia_id   INT NOT NULL,
  titulo       VARCHAR(200) NOT NULL,
  descripcion  TEXT,
  archivo      VARCHAR(255),
  fecha_limite DATE,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (profesor_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (materia_id) REFERENCES materias(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS entregas (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  actividad_id  INT NOT NULL,
  estudiante_id INT NOT NULL,
  archivo       VARCHAR(255),
  estado        ENUM('entregado','tarde') DEFAULT 'entregado',
  calificacion  DECIMAL(4,2),
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (actividad_id, estudiante_id),
  FOREIGN KEY (actividad_id) REFERENCES actividades(id) ON DELETE CASCADE,
  FOREIGN KEY (estudiante_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS notificaciones (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  titulo     VARCHAR(200) NOT NULL,
  mensaje    TEXT,
  tipo       ENUM('nota','actividad','vencimiento') DEFAULT 'nota',
  leido      TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS recuperacion_password (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  estado     ENUM('pendiente','atendido') DEFAULT 'pendiente',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

INSERT INTO cursos (id, nombre) VALUES (1, 'Curso General');

INSERT INTO usuarios (nombre, email, password, rol)
VALUES ('Administrador', 'admin@galan.edu.co', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'administrador');