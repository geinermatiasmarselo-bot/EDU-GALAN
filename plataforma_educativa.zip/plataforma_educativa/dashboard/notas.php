<?php
session_start();
include '../includes/conexion.php';
// NO incluir asistente aquí para evitar salida antes de header

if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'profesor') {
    header("Location: ../index.php");
    exit();
}

$profesor_id = $_SESSION['id'];
$mensaje = "";
$error = "";

// Obtener materias asignadas a este profesor
$sql_mis_materias = "SELECT m.id, m.nombre, m.grado FROM materias m
                     JOIN profesor_materias pm ON m.id = pm.materia_id
                     WHERE pm.profesor_id = $profesor_id
                     ORDER BY m.grado, m.nombre";
$mis_materias = mysqli_query($conexion, $sql_mis_materias);
$materias_array = [];
while ($m = mysqli_fetch_assoc($mis_materias)) {
    $materias_array[] = $m;
}

// Registrar nota
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $estudiante_id = $_POST['estudiante_id'] ?? null;
    $materia_id = $_POST['materia_id'] ?? null;
    $nota = $_POST['nota'] ?? null;
    $periodo = $_POST['periodo'] ?? null;
    $observacion = $_POST['observacion'] ?? '';

    // Validaciones
    if (!$estudiante_id || !$materia_id || !$nota || !$periodo) {
        $error = "❌ Todos los campos son obligatorios (incluido el periodo).";
    } else {
        // Verificar que la materia pertenece a este profesor
        $verificar_mat = "SELECT id FROM profesor_materias WHERE profesor_id=$profesor_id AND materia_id=$materia_id";
        $res_mat = mysqli_query($conexion, $verificar_mat);
        if (mysqli_num_rows($res_mat) == 0) {
            $error = "❌ No tienes permiso para registrar notas en esta materia";
        } else {
            // Verificar si ya existe una nota para ese estudiante, materia y periodo
            $verificar = "SELECT id FROM notas WHERE estudiante_id=$estudiante_id AND materia_id=$materia_id AND periodo='$periodo'";
            $res = mysqli_query($conexion, $verificar);
            if (mysqli_num_rows($res) > 0) {
                $sql = "UPDATE notas SET nota=$nota, observacion='$observacion' 
                        WHERE estudiante_id=$estudiante_id AND materia_id=$materia_id AND periodo='$periodo'";
            } else {
                $sql = "INSERT INTO notas (estudiante_id, materia_id, nota, periodo, observacion) 
                        VALUES ($estudiante_id, $materia_id, $nota, '$periodo', '$observacion')";
            }

            if (mysqli_query($conexion, $sql)) {
                // Notificación al estudiante
                $titulo = "Nueva nota registrada";
                $mensaje_notif = "Se ha registrado una nota de $nota en el $periodo";
                $sql_notif = "INSERT INTO notificaciones (usuario_id, titulo, mensaje, tipo) 
                              VALUES ($estudiante_id, '$titulo', '$mensaje_notif', 'nota')";
                mysqli_query($conexion, $sql_notif);
                $mensaje = "✅ Nota guardada correctamente en $periodo";
            } else {
                $error = "❌ Error al guardar la nota: " . mysqli_error($conexion);
            }
        }
    }
}

// Filtros
$grado_filtro = $_GET['grado'] ?? '';
$periodo_filtro = $_GET['periodo_filtro'] ?? '';

// Obtener estudiantes según filtro
if ($grado_filtro) {
    $sql_estudiantes = "SELECT id, nombre, grado FROM usuarios WHERE rol='estudiante' AND grado='$grado_filtro' ORDER BY nombre";
} else {
    $sql_estudiantes = "SELECT id, nombre, grado FROM usuarios WHERE rol='estudiante' ORDER BY nombre";
}
$estudiantes = mysqli_query($conexion, $sql_estudiantes);

// Obtener notas registradas por este profesor con filtros
$where = "WHERE pm.profesor_id = $profesor_id";
if ($grado_filtro) $where .= " AND u.grado = '$grado_filtro'";
if ($periodo_filtro) $where .= " AND n.periodo = '$periodo_filtro'";

$sql_notas = "SELECT n.*, u.nombre as estudiante, u.grado, m.nombre as materia 
              FROM notas n
              JOIN usuarios u ON n.estudiante_id = u.id
              JOIN materias m ON n.materia_id = m.id
              JOIN profesor_materias pm ON m.id = pm.materia_id
              $where
              ORDER BY n.created_at DESC";
$lista_notas = mysqli_query($conexion, $sql_notas);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Notas - Profesor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/estilos.css">
    <style>
        .badge-periodo {
            font-size: 0.8rem;
            padding: 5px 8px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-dark bg-primary">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="profesor.php">🏫 Plataforma Educativa</a>
        <div class="ms-auto d-flex gap-2">
            <a href="profesor.php" class="btn btn-outline-light btn-sm">⬅ Volver</a>
            <a href="../cerrar_sesion.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h4 class="mb-4">📊 Gestión de Notas</h4>

    <?php if (empty($materias_array)): ?>
        <div class="alert alert-warning">⚠️ No tienes materias asignadas. Contacta al administrador.</div>
    <?php else: ?>
        <?php if ($mensaje): ?>
            <div class="alert alert-success"><?= $mensaje ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <!-- Filtros combinados -->
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-secondary text-white">🔍 Filtros</div>
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Grado</label>
                        <select name="grado" class="form-select" onchange="this.form.submit()">
                            <option value="">Todos los grados</option>
                            <?php foreach (['Grado 6','Grado 7','Grado 8','Grado 9','Grado 10','Grado 11'] as $g): ?>
                                <option value="<?= $g ?>" <?= $grado_filtro==$g ? 'selected' : '' ?>><?= $g ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Periodo</label>
                        <select name="periodo_filtro" class="form-select" onchange="this.form.submit()">
                            <option value="">Todos los periodos</option>
                            <?php foreach (['Periodo 1','Periodo 2','Periodo 3','Periodo 4'] as $p): ?>
                                <option value="<?= $p ?>" <?= $periodo_filtro==$p ? 'selected' : '' ?>><?= $p ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4 d-flex align-items-end">
                        <a href="notas.php" class="btn btn-outline-secondary">Limpiar filtros</a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Formulario registrar nota -->
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-primary text-white">✏️ Registrar / Actualizar Nota</div>
            <div class="card-body">
                <form method="POST">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label">Estudiante</label>
                            <select name="estudiante_id" class="form-select" required>
                                <option value="">Seleccionar...</option>
                                <?php mysqli_data_seek($estudiantes, 0); while ($e = mysqli_fetch_assoc($estudiantes)): ?>
                                    <option value="<?= $e['id'] ?>"><?= $e['nombre'] ?> (<?= $e['grado'] ?>)</option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Materia</label>
                            <select name="materia_id" class="form-select" required>
                                <option value="">Seleccionar...</option>
                                <?php foreach ($materias_array as $m): ?>
                                    <option value="<?= $m['id'] ?>"><?= $m['nombre'] ?> (<?= $m['grado'] ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Nota (0-10)</label>
                            <input type="number" name="nota" class="form-control" min="0" max="10" step="0.1" required>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Periodo</label>
                            <select name="periodo" class="form-select" required>
                                <option value="">Seleccionar...</option>
                                <option value="Periodo 1">Periodo 1</option>
                                <option value="Periodo 2">Periodo 2</option>
                                <option value="Periodo 3">Periodo 3</option>
                                <option value="Periodo 4">Periodo 4</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Observación</label>
                            <input type="text" name="observacion" class="form-control" placeholder="Opcional">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mt-3">💾 Guardar Nota</button>
                </form>
            </div>
        </div>

        <!-- Tabla de notas registradas -->
        <div class="card shadow-sm">
            <div class="card-header bg-secondary text-white">
                📋 Mis Notas Registradas
                <?= $grado_filtro ? "— $grado_filtro" : "" ?>
                <?= $periodo_filtro ? "— $periodo_filtro" : "" ?>
            </div>
            <div class="card-body table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>Estudiante</th>
                            <th>Grado</th>
                            <th>Materia</th>
                            <th>Nota</th>
                            <th>Periodo</th>
                            <th>Observación</th>
                            <th>Fecha</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (mysqli_num_rows($lista_notas) > 0): ?>
                            <?php while ($n = mysqli_fetch_assoc($lista_notas)): 
                                $periodo_color = [
                                    'Periodo 1' => 'primary',
                                    'Periodo 2' => 'success',
                                    'Periodo 3' => 'warning',
                                    'Periodo 4' => 'danger'
                                ];
                                $color = $periodo_color[$n['periodo']] ?? 'secondary';
                            ?>
                                <tr>
                                    <td><?= htmlspecialchars($n['estudiante']) ?></td>
                                    <td><?= $n['grado'] ?></td>
                                    <td><?= htmlspecialchars($n['materia']) ?></td>
                                    <td>
                                        <span class="badge <?= $n['nota'] >= 6 ? 'bg-success' : 'bg-danger' ?> fs-6">
                                            <?= $n['nota'] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?= $color ?> badge-periodo">
                                            <?= $n['periodo'] ?>
                                        </span>
                                    </td>
                                    <td><?= htmlspecialchars($n['observacion'] ?? '-') ?></td>
                                    <td><?= date('d/m/Y', strtotime($n['created_at'])) ?></td>
                                    <td>
                                        <a href="perfil_estudiante.php?id=<?= $n['estudiante_id'] ?>" class="btn btn-sm btn-outline-primary">
                                            Ver perfil
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted">Sin notas registradas con los filtros actuales</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- Incluir asistente al final para evitar problemas con header -->
<?php include '../includes/asistente.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>