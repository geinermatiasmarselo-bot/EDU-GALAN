<?php
session_start();
include '../includes/conexion.php';
 include '../includes/asistente.php';
if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'estudiante') {
    header("Location: ../index.php");
    exit();
}

$id_estudiante = $_SESSION['id'];

// Notificaciones no leídas
$sql_notif = "SELECT COUNT(*) as total FROM notificaciones WHERE usuario_id=$id_estudiante AND leido=0";
$res_notif = mysqli_query($conexion, $sql_notif);
$total_notif = mysqli_fetch_assoc($res_notif)['total'];

// Datos del estudiante
$sql_est = "SELECT * FROM usuarios WHERE id=$id_estudiante";
$res_est = mysqli_query($conexion, $sql_est);
$estudiante = mysqli_fetch_assoc($res_est);

// Promedio general
$sql_prom = "SELECT AVG(nota) as promedio FROM notas WHERE estudiante_id=$id_estudiante";
$res_prom = mysqli_query($conexion, $sql_prom);
$promedio = mysqli_fetch_assoc($res_prom)['promedio'];

// Total ausencias
$sql_aus = "SELECT COUNT(*) as total FROM asistencia WHERE estudiante_id=$id_estudiante AND estado='ausente'";
$res_aus = mysqli_query($conexion, $sql_aus);
$total_aus = mysqli_fetch_assoc($res_aus)['total'];

// Notificaciones recientes
$sql_recientes = "SELECT * FROM notificaciones WHERE usuario_id=$id_estudiante ORDER BY created_at DESC LIMIT 3";
$recientes = mysqli_query($conexion, $sql_recientes);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Estudiante — José Antonio Galán</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-success">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="#">
            <img src="../assets/logo.png" alt="Logo"> Colegio José Antonio Galán
        </a>
        <div class="ms-auto d-flex align-items-center gap-3">
            <a href="notificaciones.php" class="btn btn-outline-light btn-sm position-relative">
                🔔
                <?php if ($total_notif > 0): ?>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        <?= $total_notif ?>
                    </span>
                <?php endif; ?>
            </a>
            <span class="text-white small">👤 <?= $_SESSION['nombre'] ?></span>
            <a href="../cerrar_sesion.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-4">

    <div class="mb-4">
        <h4 class="fw-bold">Bienvenido, <?= $_SESSION['nombre'] ?> 👋</h4>
        <p class="text-muted"><?= $estudiante['grado'] ?> — <?= date('d/m/Y') ?></p>
    </div>

    <!-- Tarjetas resumen -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card shadow-sm p-3 d-flex flex-row align-items-center gap-3">
                <div class="fs-1">📊</div>
                <div>
                    <h3 class="mb-0 fw-bold text-primary">
                        <?= $promedio ? round($promedio, 1) : '—' ?>
                    </h3>
                    <p class="mb-0 text-muted small">Promedio general</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm p-3 d-flex flex-row align-items-center gap-3">
                <div class="fs-1">❌</div>
                <div>
                    <h3 class="mb-0 fw-bold text-danger"><?= $total_aus ?></h3>
                    <p class="mb-0 text-muted small">Ausencias registradas</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm p-3 d-flex flex-row align-items-center gap-3">
                <div class="fs-1">🔔</div>
                <div>
                    <h3 class="mb-0 fw-bold text-warning"><?= $total_notif ?></h3>
                    <p class="mb-0 text-muted small">Notificaciones nuevas</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Módulos -->
    <h5 class="fw-bold mb-3">Mis Módulos</h5>
    <div class="row g-4">
        <div class="col-md-3">
            <div class="card text-center shadow-sm h-100 p-2">
                <div class="card-body">
                    <div class="fs-1 mb-2">📊</div>
                    <h5 class="card-title fw-bold">Mis Notas</h5>
                    <p class="card-text text-muted small">Consulta tus calificaciones</p>
                    <a href="mis_notas.php" class="btn btn-primary btn-sm w-100">Ver Notas</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm h-100 p-2">
                <div class="card-body">
                    <div class="fs-1 mb-2">✅</div>
                    <h5 class="card-title fw-bold">Mi Asistencia</h5>
                    <p class="card-text text-muted small">Revisa tu registro de asistencia</p>
                    <a href="mi_asistencia.php" class="btn btn-success btn-sm w-100">Ver Asistencia</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm h-100 p-2">
                <div class="card-body">
                    <div class="fs-1 mb-2">📋</div>
                    <h5 class="card-title fw-bold">Mis Formativos</h5>
                    <p class="card-text text-muted small">Revisa tus anotaciones</p>
                    <a href="mis_formativos.php" class="btn btn-warning btn-sm w-100">Ver Formativos</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm h-100 p-2">
                <div class="card-body">
                    <div class="fs-1 mb-2">📁</div>
                    <h5 class="card-title fw-bold">Actividades</h5>
                    <p class="card-text text-muted small">Ver y entregar actividades</p>
                    <a href="mis_actividades.php" class="btn btn-info btn-sm w-100">Ver Actividades</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Notificaciones recientes -->
    <?php if (mysqli_num_rows($recientes) > 0): ?>
    <div class="mt-5">
        <h5 class="fw-bold">🔔 Notificaciones recientes</h5>
        <div class="list-group">
            <?php while ($n = mysqli_fetch_assoc($recientes)): ?>
                <div class="list-group-item border-0 shadow-sm mb-2 rounded-3 <?= $n['leido'] == 0 ? 'list-group-item-warning' : '' ?>">
                    <strong><?= $n['titulo'] ?></strong>
                    <p class="mb-0 text-muted small"><?= $n['mensaje'] ?></p>
                    <small class="text-muted"><?= date('d/m/Y H:i', strtotime($n['created_at'])) ?></small>
                </div>
            <?php endwhile; ?>
        </div>
        <a href="notificaciones.php" class="btn btn-outline-secondary btn-sm mt-2">Ver todas</a>
    </div>
    <?php endif; ?>

</div>

</body>
</html>