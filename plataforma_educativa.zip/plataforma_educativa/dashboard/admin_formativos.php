<?php
session_start();
include '../includes/conexion.php';

if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'administrador') {
    header("Location: ../index.php");
    exit();
}

$mensaje = "";
$error = "";

// Eliminar formativo
if (isset($_POST['accion']) && $_POST['accion'] == 'eliminar') {
    $formativo_id = $_POST['formativo_id'];
    $sql = "DELETE FROM formativos WHERE id=$formativo_id";
    if (mysqli_query($conexion, $sql)) {
        $mensaje = "✅ Formativo eliminado correctamente";
    } else {
        $error = "❌ Error al eliminar el formativo";
    }
}

// Filtros
$grado_filtro = isset($_GET['grado']) ? $_GET['grado'] : '';
$tipo_filtro = isset($_GET['tipo']) ? $_GET['tipo'] : '';

$where = "WHERE 1=1";
if ($grado_filtro) $where .= " AND u.grado='$grado_filtro'";
if ($tipo_filtro) $where .= " AND f.tipo='$tipo_filtro'";

$sql_formativos = "SELECT f.*, u.nombre as estudiante, u.grado, p.nombre as profesor
                   FROM formativos f
                   JOIN usuarios u ON f.estudiante_id = u.id
                   JOIN usuarios p ON f.profesor_id = p.id
                   $where
                   ORDER BY f.fecha DESC";
$lista_formativos = mysqli_query($conexion, $sql_formativos);

// Conteos
$total_formativos = mysqli_fetch_assoc(mysqli_query($conexion, "SELECT COUNT(*) as t FROM formativos"))['t'];
$total_llamados = mysqli_fetch_assoc(mysqli_query($conexion, "SELECT COUNT(*) as t FROM formativos WHERE tipo='llamado_escrito'"))['t'];
$total_citaciones = mysqli_fetch_assoc(mysqli_query($conexion, "SELECT COUNT(*) as t FROM formativos WHERE tipo='citacion_padres'"))['t'];
$total_suspensiones = mysqli_fetch_assoc(mysqli_query($conexion, "SELECT COUNT(*) as t FROM formativos WHERE tipo='suspension'"))['t'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formativos — Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<nav class="navbar navbar-dark" style="background: linear-gradient(135deg, #1e293b, #0f172a);">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="admin.php">
            <img src="../assets/logo.png" alt="Logo"> Colegio José Antonio Galán
        </a>
        <div class="ms-auto d-flex gap-2">
            <a href="admin.php" class="btn btn-outline-light btn-sm">⬅ Volver</a>
            <a href="../cerrar_sesion.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h4 class="fw-bold mb-4">📋 Gestión de Formativos</h4>

    <?php if ($mensaje): ?>
        <div class="alert alert-success"><?= $mensaje ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <!-- Resumen -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card text-center shadow-sm border-0 p-3">
                <div class="fs-1">📋</div>
                <h3 class="fw-bold text-secondary"><?= $total_formativos ?></h3>
                <small class="text-muted">Total formativos</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm border-0 p-3">
                <div class="fs-1">⚠️</div>
                <h3 class="fw-bold text-warning"><?= $total_llamados ?></h3>
                <small class="text-muted">Llamados escritos</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm border-0 p-3">
                <div class="fs-1">👨‍👩‍👧</div>
                <h3 class="fw-bold text-info"><?= $total_citaciones ?></h3>
                <small class="text-muted">Citaciones a padres</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm border-0 p-3">
                <div class="fs-1">🚫</div>
                <h3 class="fw-bold text-danger"><?= $total_suspensiones ?></h3>
                <small class="text-muted">Suspensiones</small>
            </div>
        </div>
    </div>

    <!-- Filtros -->
    <div class="card shadow-sm mb-4">
        <div class="card-header fw-bold" style="background: linear-gradient(135deg, #1e293b, #0f172a); color:white;">
            🔍 Filtros
        </div>
        <div class="card-body">
            <form method="GET">
                <div class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Grado</label>
                        <select name="grado" class="form-select" onchange="this.form.submit()">
                            <option value="">Todos los grados</option>
                            <option value="Grado 6"  <?= $grado_filtro=='Grado 6'  ? 'selected':'' ?>>Grado 6</option>
                            <option value="Grado 7"  <?= $grado_filtro=='Grado 7'  ? 'selected':'' ?>>Grado 7</option>
                            <option value="Grado 8"  <?= $grado_filtro=='Grado 8'  ? 'selected':'' ?>>Grado 8</option>
                            <option value="Grado 9"  <?= $grado_filtro=='Grado 9'  ? 'selected':'' ?>>Grado 9</option>
                            <option value="Grado 10" <?= $grado_filtro=='Grado 10' ? 'selected':'' ?>>Grado 10</option>
                            <option value="Grado 11" <?= $grado_filtro=='Grado 11' ? 'selected':'' ?>>Grado 11</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Tipo</label>
                        <select name="tipo" class="form-select" onchange="this.form.submit()">
                            <option value="">Todos los tipos</option>
                            <option value="llamado_escrito" <?= $tipo_filtro=='llamado_escrito' ? 'selected':'' ?>>⚠️ Llamado escrito</option>
                            <option value="citacion_padres" <?= $tipo_filtro=='citacion_padres' ? 'selected':'' ?>>👨‍👩‍👧 Citación a padres</option>
                            <option value="suspension"      <?= $tipo_filtro=='suspension'      ? 'selected':'' ?>>🚫 Suspensión</option>
                        </select>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabla formativos -->
    <div class="card shadow-sm">
        <div class="card-header fw-bold" style="background: linear-gradient(135deg, #1e293b, #0f172a); color:white;">
            📋 Todos los Formativos
        </div>
        <div class="card-body table-responsive">
            <table class="table table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Estudiante</th>
                        <th>Grado</th>
                        <th>Profesor</th>
                        <th>Tipo</th>
                        <th>Descripción</th>
                        <th>Afecta nota</th>
                        <th>Estado</th>
                        <th>Fecha</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $hay = false;
                    while ($f = mysqli_fetch_assoc($lista_formativos)):
                        $hay = true;
                        $color = match($f['tipo']) {
                            'llamado_escrito' => 'warning',
                            'citacion_padres' => 'info',
                            'suspension'      => 'danger',
                            default           => 'secondary'
                        };
                        $tipo_texto = match($f['tipo']) {
                            'llamado_escrito' => '⚠️ Llamado Escrito',
                            'citacion_padres' => '👨‍👩‍👧 Citación Padres',
                            'suspension'      => '🚫 Suspensión',
                            default           => $f['tipo']
                        };
                    ?>
                    <tr>
                        <td><strong><?= $f['estudiante'] ?></strong></td>
                        <td><?= $f['grado'] ?></td>
                        <td><?= $f['profesor'] ?></td>
                        <td>
                            <span class="badge bg-<?= $color ?> <?= $color=='warning' ? 'text-dark':'' ?>">
                                <?= $tipo_texto ?>
                            </span>
                        </td>
                        <td>
                            <small><?= strlen($f['descripcion']) > 40
                                ? substr($f['descripcion'],0,40).'...'
                                : $f['descripcion'] ?>
                            </small>
                        </td>
                        <td>
                            <?php if ($f['afecta_nota'] > 0): ?>
                                <span class="badge bg-danger">-<?= $f['afecta_nota'] ?></span>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge <?= $f['firmado']=='firmado' ? 'bg-success' : 'bg-secondary' ?>">
                                <?= $f['firmado']=='firmado' ? '✅ Firmado' : '⏳ Pendiente' ?>
                            </span>
                        </td>
                        <td><small><?= date('d/m/Y', strtotime($f['fecha'])) ?></small></td>
                        <td>
                            <form method="POST">
                                <input type="hidden" name="accion" value="eliminar">
                                <input type="hidden" name="formativo_id" value="<?= $f['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger"
                                        onclick="return confirm('¿Eliminar este formativo?')">
                                    🗑️
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    <?php if (!$hay): ?>
                        <tr>
                            <td colspan="9" class="text-center text-muted">Sin formativos registrados</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/asistente.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>