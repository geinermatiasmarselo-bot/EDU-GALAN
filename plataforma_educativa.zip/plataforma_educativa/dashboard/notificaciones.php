<?php
session_start();
include '../includes/conexion.php';

if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'estudiante') {
    header("Location: ../index.php");
    exit();
}

$estudiante_id = $_SESSION['id'];

// Marcar todas como leídas al abrir
$sql_leer = "UPDATE notificaciones SET leido=1 WHERE usuario_id=$estudiante_id";
mysqli_query($conexion, $sql_leer);

// Conteo por tipo
$sql_conteo = "SELECT 
    SUM(CASE WHEN tipo='nota' THEN 1 ELSE 0 END) as notas,
    SUM(CASE WHEN tipo='actividad' THEN 1 ELSE 0 END) as actividades,
    SUM(CASE WHEN tipo='vencimiento' THEN 1 ELSE 0 END) as vencimientos,
    COUNT(*) as total
    FROM notificaciones WHERE usuario_id=$estudiante_id";
$res_conteo = mysqli_query($conexion, $sql_conteo);
$conteo = mysqli_fetch_assoc($res_conteo);

// Todas las notificaciones
$sql_notif = "SELECT * FROM notificaciones WHERE usuario_id=$estudiante_id ORDER BY created_at DESC";
$notificaciones = mysqli_query($conexion, $sql_notif);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notificaciones</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<nav class="navbar navbar-dark bg-success">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="estudiante.php">
            <img src="../assets/logo.png" alt="Logo"> Colegio José Antonio Galán
        </a>
        <div class="ms-auto d-flex gap-2">
            <a href="estudiante.php" class="btn btn-outline-light btn-sm">⬅ Volver</a>
            <a href="../cerrar_sesion.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-4">

    <h4 class="fw-bold mb-4">🔔 Mis Notificaciones</h4>

    <!-- Tarjetas resumen -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card text-center shadow-sm border-0 p-2">
                <div class="fs-1">🔔</div>
                <h3 class="fw-bold text-secondary"><?= $conteo['total'] ?? 0 ?></h3>
                <small class="text-muted">Total</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm border-0 p-2">
                <div class="fs-1">📊</div>
                <h3 class="fw-bold text-primary"><?= $conteo['notas'] ?? 0 ?></h3>
                <small class="text-muted">Notas</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm border-0 p-2">
                <div class="fs-1">📁</div>
                <h3 class="fw-bold text-info"><?= $conteo['actividades'] ?? 0 ?></h3>
                <small class="text-muted">Actividades</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm border-0 p-2">
                <div class="fs-1">⏰</div>
                <h3 class="fw-bold text-warning"><?= $conteo['vencimientos'] ?? 0 ?></h3>
                <small class="text-muted">Vencimientos</small>
            </div>
        </div>
    </div>

    <!-- Tabs por tipo -->
    <ul class="nav nav-tabs mb-4">
        <li class="nav-item">
            <a class="nav-link active" data-bs-toggle="tab" href="#todas">
                🔔 Todas <span class="badge bg-secondary"><?= $conteo['total'] ?? 0 ?></span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#tab_notas">
                📊 Notas <span class="badge bg-primary"><?= $conteo['notas'] ?? 0 ?></span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#tab_actividades">
                📁 Actividades <span class="badge bg-info"><?= $conteo['actividades'] ?? 0 ?></span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#tab_vencimientos">
                ⏰ Vencimientos <span class="badge bg-warning text-dark"><?= $conteo['vencimientos'] ?? 0 ?></span>
            </a>
        </li>
    </ul>

    <div class="tab-content">

        <?php
        // Función para mostrar lista de notificaciones
        function mostrarNotificaciones($notificaciones, $filtro = null) {
            $hay = false;
            while ($n = mysqli_fetch_assoc($notificaciones)):
                if ($filtro && $n['tipo'] != $filtro) continue;
                $hay = true;

                $icono = match($n['tipo']) {
                    'nota'        => '📊',
                    'actividad'   => '📁',
                    'vencimiento' => '⏰',
                    default       => '🔔'
                };
                $color = match($n['tipo']) {
                    'nota'        => 'primary',
                    'actividad'   => 'info',
                    'vencimiento' => 'warning',
                    default       => 'secondary'
                };
        ?>
                <div class="card shadow-sm mb-3 border-0 border-start border-<?= $color ?> border-4">
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center gap-3">
                            <div class="fs-2"><?= $icono ?></div>
                            <div>
                                <h6 class="fw-bold mb-0"><?= $n['titulo'] ?></h6>
                                <p class="text-muted mb-0 small"><?= $n['mensaje'] ?></p>
                            </div>
                        </div>
                        <small class="text-muted text-nowrap">
                            <?= date('d/m/Y H:i', strtotime($n['created_at'])) ?>
                        </small>
                    </div>
                </div>
        <?php
            endwhile;
            if (!$hay) {
                echo '<div class="alert alert-info">📭 Sin notificaciones en esta categoría.</div>';
            }
        }
        ?>

        <!-- Tab todas -->
        <div class="tab-pane fade show active" id="todas">
            <?php
            mysqli_data_seek($notificaciones, 0);
            mostrarNotificaciones($notificaciones);
            ?>
        </div>

        <!-- Tab notas -->
        <div class="tab-pane fade" id="tab_notas">
            <?php
            mysqli_data_seek($notificaciones, 0);
            mostrarNotificaciones($notificaciones, 'nota');
            ?>
        </div>

        <!-- Tab actividades -->
        <div class="tab-pane fade" id="tab_actividades">
            <?php
            mysqli_data_seek($notificaciones, 0);
            mostrarNotificaciones($notificaciones, 'actividad');
            ?>
        </div>

        <!-- Tab vencimientos -->
        <div class="tab-pane fade" id="tab_vencimientos">
            <?php
            mysqli_data_seek($notificaciones, 0);
            mostrarNotificaciones($notificaciones, 'vencimiento');
            ?>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>