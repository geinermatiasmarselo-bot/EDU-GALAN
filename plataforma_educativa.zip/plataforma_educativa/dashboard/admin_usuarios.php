<?php
session_start();
include '../includes/conexion.php';

if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'administrador') {
    header("Location: ../index.php");
    exit();
}

$mensaje = "";
$error = "";

// Cambiar contraseña normal
if (isset($_POST['accion']) && $_POST['accion'] == 'cambiar_pass') {
    $usuario_id = $_POST['usuario_id'];
    $nueva_pass = password_hash($_POST['nueva_password'], PASSWORD_DEFAULT);
    $sql = "UPDATE usuarios SET password='$nueva_pass' WHERE id=$usuario_id";
    if (mysqli_query($conexion, $sql)) {
        $mensaje = "✅ Contraseña actualizada correctamente";
    } else {
        $error = "❌ Error al actualizar contraseña";
    }
}

// Cambiar contraseña por solicitud
if (isset($_POST['accion']) && $_POST['accion'] == 'cambiar_pass_solicitud') {
    $usuario_id = $_POST['usuario_id'];
    $solicitud_id = $_POST['solicitud_id'];
    $nueva_pass = password_hash($_POST['nueva_password'], PASSWORD_DEFAULT);

    mysqli_query($conexion, "UPDATE usuarios SET password='$nueva_pass' WHERE id=$usuario_id");
    mysqli_query($conexion, "UPDATE recuperacion_password SET estado='atendido' WHERE id=$solicitud_id");

    $sql_notif = "INSERT INTO notificaciones (usuario_id, titulo, mensaje, tipo) 
                  VALUES ($usuario_id, '🔑 Contraseña actualizada', 
                  'Tu contraseña fue cambiada por el administrador. Ya puedes iniciar sesión.', 'nota')";
    mysqli_query($conexion, $sql_notif);
    $mensaje = "✅ Contraseña cambiada y usuario notificado";
}

// Editar usuario
if (isset($_POST['accion']) && $_POST['accion'] == 'editar') {
    $usuario_id = $_POST['usuario_id'];
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $rol = $_POST['rol'];
    $grado = $_POST['grado'] ?? NULL;

    $sql = "UPDATE usuarios SET nombre='$nombre', email='$email', rol='$rol', grado='$grado' WHERE id=$usuario_id";
    if (mysqli_query($conexion, $sql)) {
        $mensaje = "✅ Usuario actualizado correctamente";
    } else {
        $error = "❌ Error al actualizar usuario";
    }
}

// Eliminar usuario
if (isset($_POST['accion']) && $_POST['accion'] == 'eliminar') {
    $usuario_id = $_POST['usuario_id'];
    $sql = "DELETE FROM usuarios WHERE id=$usuario_id AND rol != 'administrador'";
    if (mysqli_query($conexion, $sql)) {
        $mensaje = "✅ Usuario eliminado correctamente";
    } else {
        $error = "❌ Error al eliminar usuario";
    }
}

// Filtro por rol
$rol_filtro = isset($_GET['rol']) ? $_GET['rol'] : '';
if ($rol_filtro) {
    $sql_usuarios = "SELECT * FROM usuarios WHERE rol='$rol_filtro' ORDER BY nombre";
} else {
    $sql_usuarios = "SELECT * FROM usuarios WHERE rol != 'administrador' ORDER BY rol, nombre";
}
$usuarios = mysqli_query($conexion, $sql_usuarios);

// Solicitudes pendientes
$sql_sol = "SELECT r.*, u.nombre, u.email, u.rol FROM recuperacion_password r
            JOIN usuarios u ON r.usuario_id = u.id
            WHERE r.estado='pendiente'
            ORDER BY r.created_at DESC";
$solicitudes = mysqli_query($conexion, $sql_sol);
$total_sol = mysqli_num_rows($solicitudes);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Usuarios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<nav class="navbar navbar-dark" style="background: linear-gradient(135deg, #1e293b, #0f172a);">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="admin.php">
            <img src="../assets/logo.png" alt="Logo"> Colegio José Antonio Galán
        </a>
        <div class="ms-auto d-flex gap-2">
            <a href="admin.php" class="btn btn-outline-light btn-sm">⬅ Volver</a>
            <a href="../cerrar_sesion.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h4 class="fw-bold mb-4">👥 Gestión de Usuarios</h4>

    <?php if ($mensaje): ?>
        <div class="alert alert-success"><?= $mensaje ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <!-- Solicitudes pendientes -->
    <?php if ($total_sol > 0): ?>
    <div class="card shadow-sm mb-4 border-danger border-2">
        <div class="card-header bg-danger text-white fw-bold">
            🔑 Solicitudes de Recuperación de Contraseña (<?= $total_sol ?>)
        </div>
        <div class="card-body table-responsive">
            <table class="table table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Usuario</th>
                        <th>Email</th>
                        <th>Rol</th>
                        <th>Fecha solicitud</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($s = mysqli_fetch_assoc($solicitudes)): ?>
                    <tr>
                        <td><strong><?= $s['nombre'] ?></strong></td>
                        <td><?= $s['email'] ?></td>
                        <td><span class="badge bg-primary"><?= ucfirst($s['rol']) ?></span></td>
                        <td><?= date('d/m/Y H:i', strtotime($s['created_at'])) ?></td>
                        <td>
                            <button class="btn btn-sm btn-warning"
                                onclick="abrirPassSolicitud(<?= $s['usuario_id'] ?>, '<?= addslashes($s['nombre']) ?>', <?= $s['id'] ?>)">
                                🔑 Cambiar contraseña
                            </button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

    <!-- Filtro por rol -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <form method="GET">
                <div class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Filtrar por rol</label>
                        <select name="rol" class="form-select" onchange="this.form.submit()">
                            <option value="">Todos los usuarios</option>
                            <option value="estudiante" <?= $rol_filtro=='estudiante' ? 'selected':'' ?>>Estudiantes</option>
                            <option value="profesor"   <?= $rol_filtro=='profesor'   ? 'selected':'' ?>>Profesores</option>
                        </select>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabla usuarios -->
    <div class="card shadow-sm">
        <div class="card-header fw-bold" style="background: linear-gradient(135deg, #1e293b, #0f172a); color:white;">
            👥 Lista de Usuarios
        </div>
        <div class="card-body table-responsive">
            <table class="table table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Nombre</th>
                        <th>Email</th>
                        <th>Rol</th>
                        <th>Grado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $hay = false;
                    while ($u = mysqli_fetch_assoc($usuarios)):
                        $hay = true;
                        $color = match($u['rol']) {
                            'estudiante' => 'primary',
                            'profesor'   => 'success',
                            default      => 'secondary'
                        };
                    ?>
                    <tr>
                        <td><strong><?= $u['nombre'] ?></strong></td>
                        <td><?= $u['email'] ?></td>
                        <td><span class="badge bg-<?= $color ?>"><?= ucfirst($u['rol']) ?></span></td>
                        <td><?= $u['grado'] ?? '—' ?></td>
                        <td>
                            <div class="d-flex gap-1">
                                <button class="btn btn-sm btn-outline-primary"
                                    onclick="abrirEditar(<?= $u['id'] ?>, '<?= addslashes($u['nombre']) ?>', '<?= $u['email'] ?>', '<?= $u['rol'] ?>', '<?= $u['grado'] ?>')">
                                    ✏️
                                </button>
                                <button class="btn btn-sm btn-outline-warning"
                                    onclick="abrirPass(<?= $u['id'] ?>, '<?= addslashes($u['nombre']) ?>')">
                                    🔑
                                </button>
                                <form method="POST" onsubmit="return confirm('¿Seguro que deseas eliminar este usuario?')">
                                    <input type="hidden" name="accion" value="eliminar">
                                    <input type="hidden" name="usuario_id" value="<?= $u['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger">🗑️</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    <?php if (!$hay): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted">No hay usuarios registrados</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Editar Usuario -->
<div class="modal fade" id="modalEditar" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(135deg, #1e293b, #0f172a); color:white;">
                <h5 class="modal-title">✏️ Editar Usuario</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="accion" value="editar">
                <input type="hidden" name="usuario_id" id="edit_id">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Nombre</label>
                        <input type="text" name="nombre" id="edit_nombre" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Email</label>
                        <input type="email" name="email" id="edit_email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Rol</label>
                        <select name="rol" id="edit_rol" class="form-select" onchange="toggleGradoModal()">
                            <option value="estudiante">Estudiante</option>
                            <option value="profesor">Profesor</option>
                        </select>
                    </div>
                    <div class="mb-3" id="edit_campo_grado">
                        <label class="form-label fw-semibold">Grado</label>
                        <select name="grado" id="edit_grado" class="form-select">
                            <option value="">Sin grado</option>
                            <option value="Grado 6">Grado 6</option>
                            <option value="Grado 7">Grado 7</option>
                            <option value="Grado 8">Grado 8</option>
                            <option value="Grado 9">Grado 9</option>
                            <option value="Grado 10">Grado 10</option>
                            <option value="Grado 11">Grado 11</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar cambios</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Cambiar Contraseña -->
<div class="modal fade" id="modalPass" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(135deg, #d97706, #f59e0b); color:white;">
                <h5 class="modal-title">🔑 Cambiar Contraseña</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="accion" value="cambiar_pass">
                <input type="hidden" name="usuario_id" id="pass_id">
                <div class="modal-body">
                    <p>Cambiando contraseña de: <strong id="pass_nombre"></strong></p>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Nueva contraseña</label>
                        <input type="password" name="nueva_password" class="form-control"
                               placeholder="Mínimo 6 caracteres" required minlength="6">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-warning">Cambiar contraseña</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Cambiar Contraseña por Solicitud -->
<div class="modal fade" id="modalPassSolicitud" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">🔑 Cambiar Contraseña por Solicitud</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="accion" value="cambiar_pass_solicitud">
                <input type="hidden" name="usuario_id" id="sol_usuario_id">
                <input type="hidden" name="solicitud_id" id="sol_id">
                <div class="modal-body">
                    <p>Cambiando contraseña de: <strong id="sol_nombre"></strong></p>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Nueva contraseña</label>
                        <input type="password" name="nueva_password" class="form-control"
                               placeholder="Mínimo 6 caracteres" required minlength="6">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-danger">Cambiar contraseña</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/asistente.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function abrirEditar(id, nombre, email, rol, grado) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_nombre').value = nombre;
    document.getElementById('edit_email').value = email;
    document.getElementById('edit_rol').value = rol;
    document.getElementById('edit_grado').value = grado;
    toggleGradoModal();
    new bootstrap.Modal(document.getElementById('modalEditar')).show();
}

function abrirPass(id, nombre) {
    document.getElementById('pass_id').value = id;
    document.getElementById('pass_nombre').textContent = nombre;
    new bootstrap.Modal(document.getElementById('modalPass')).show();
}

function abrirPassSolicitud(usuarioId, nombre, solicitudId) {
    document.getElementById('sol_usuario_id').value = usuarioId;
    document.getElementById('sol_nombre').textContent = nombre;
    document.getElementById('sol_id').value = solicitudId;
    new bootstrap.Modal(document.getElementById('modalPassSolicitud')).show();
}

function toggleGradoModal() {
    const rol = document.getElementById('edit_rol').value;
    document.getElementById('edit_campo_grado').style.display = rol === 'estudiante' ? 'block' : 'none';
}
</script>
</body>
</html>