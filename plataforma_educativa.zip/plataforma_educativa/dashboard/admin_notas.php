<?php
session_start();
include '../includes/conexion.php';

if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'administrador') {
    header("Location: ../index.php");
    exit();
}

$mensaje = "";
$error = "";

// Modificar nota
if (isset($_POST['accion']) && $_POST['accion'] == 'editar') {
    $nota_id = $_POST['nota_id'];
    $nueva_nota = $_POST['nota'];
    $observacion = $_POST['observacion'];

    $sql = "UPDATE notas SET nota=$nueva_nota, observacion='$observacion' WHERE id=$nota_id";
    if (mysqli_query($conexion, $sql)) {
        $mensaje = "✅ Nota actualizada correctamente";
    } else {
        $error = "❌ Error al actualizar la nota";
    }
}

// Eliminar nota
if (isset($_POST['accion']) && $_POST['accion'] == 'eliminar') {
    $nota_id = $_POST['nota_id'];
    $sql = "DELETE FROM notas WHERE id=$nota_id";
    if (mysqli_query($conexion, $sql)) {
        $mensaje = "✅ Nota eliminada correctamente";
    } else {
        $error = "❌ Error al eliminar la nota";
    }
}

// Filtros
$grado_filtro = isset($_GET['grado']) ? $_GET['grado'] : '';
$periodo_filtro = isset($_GET['periodo']) ? $_GET['periodo'] : '';

$where = "WHERE 1=1";
if ($grado_filtro) $where .= " AND u.grado='$grado_filtro'";
if ($periodo_filtro) $where .= " AND n.periodo='$periodo_filtro'";

$sql_notas = "SELECT n.*, u.nombre as estudiante, u.grado, m.nombre as materia, p.nombre as profesor
              FROM notas n
              JOIN usuarios u ON n.estudiante_id = u.id
              JOIN materias m ON n.materia_id = m.id
              JOIN profesor_materias pm ON m.id = pm.materia_id
              JOIN usuarios p ON pm.profesor_id = p.id
              $where
              ORDER BY u.grado, u.nombre, n.periodo";
$lista_notas = mysqli_query($conexion, $sql_notas);

// Promedio general
$sql_prom = "SELECT AVG(nota) as promedio FROM notas";
$promedio = mysqli_fetch_assoc(mysqli_query($conexion, $sql_prom))['promedio'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Notas — Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<nav class="navbar navbar-dark" style="background: linear-gradient(135deg, #1e293b, #0f172a);">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="admin.php">
            <img src="../assets/logo.png" alt="Logo"> Colegio José Antonio Galán
        </a>
        <div class="ms-auto d-flex gap-2">
            <a href="admin.php" class="btn btn-outline-light btn-sm">⬅ Volver</a>
            <a href="../cerrar_sesion.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h4 class="fw-bold mb-4">📊 Gestión de Notas</h4>

    <?php if ($mensaje): ?>
        <div class="alert alert-success"><?= $mensaje ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <!-- Resumen -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card text-center shadow-sm border-0 p-3">
                <div class="fs-1">📈</div>
                <h3 class="fw-bold <?= ($promedio ?? 0) >= 6 ? 'text-success' : 'text-danger' ?>">
                    <?= $promedio ? round($promedio, 1) : '—' ?>
                </h3>
                <small class="text-muted">Promedio general</small>
            </div>
        </div>
    </div>

    <!-- Filtros -->
    <div class="card shadow-sm mb-4">
        <div class="card-header fw-bold" style="background: linear-gradient(135deg, #1e293b, #0f172a); color:white;">
            🔍 Filtros
        </div>
        <div class="card-body">
            <form method="GET">
                <div class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Grado</label>
                        <select name="grado" class="form-select" onchange="this.form.submit()">
                            <option value="">Todos los grados</option>
                            <option value="Grado 6"  <?= $grado_filtro=='Grado 6'  ? 'selected':'' ?>>Grado 6</option>
                            <option value="Grado 7"  <?= $grado_filtro=='Grado 7'  ? 'selected':'' ?>>Grado 7</option>
                            <option value="Grado 8"  <?= $grado_filtro=='Grado 8'  ? 'selected':'' ?>>Grado 8</option>
                            <option value="Grado 9"  <?= $grado_filtro=='Grado 9'  ? 'selected':'' ?>>Grado 9</option>
                            <option value="Grado 10" <?= $grado_filtro=='Grado 10' ? 'selected':'' ?>>Grado 10</option>
                            <option value="Grado 11" <?= $grado_filtro=='Grado 11' ? 'selected':'' ?>>Grado 11</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Periodo</label>
                        <select name="periodo" class="form-select" onchange="this.form.submit()">
                            <option value="">Todos los periodos</option>
                            <option value="Periodo 1" <?= $periodo_filtro=='Periodo 1' ? 'selected':'' ?>>Periodo 1</option>
                            <option value="Periodo 2" <?= $periodo_filtro=='Periodo 2' ? 'selected':'' ?>>Periodo 2</option>
                            <option value="Periodo 3" <?= $periodo_filtro=='Periodo 3' ? 'selected':'' ?>>Periodo 3</option>
                            <option value="Periodo 4" <?= $periodo_filtro=='Periodo 4' ? 'selected':'' ?>>Periodo 4</option>
                        </select>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabla notas -->
    <div class="card shadow-sm">
        <div class="card-header fw-bold" style="background: linear-gradient(135deg, #1e293b, #0f172a); color:white;">
            📋 Todas las Notas
        </div>
        <div class="card-body table-responsive">
            <table class="table table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Estudiante</th>
                        <th>Grado</th>
                        <th>Materia</th>
                        <th>Profesor</th>
                        <th>Nota</th>
                        <th>Periodo</th>
                        <th>Observación</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $hay = false;
                    while ($n = mysqli_fetch_assoc($lista_notas)):
                        $hay = true;
                    ?>
                    <tr>
                        <td><strong><?= $n['estudiante'] ?></strong></td>
                        <td><?= $n['grado'] ?></td>
                        <td><?= $n['materia'] ?></td>
                        <td><?= $n['profesor'] ?></td>
                        <td>
                            <span class="badge fs-6 <?= $n['nota'] >= 6 ? 'bg-success' : 'bg-danger' ?>">
                                <?= $n['nota'] ?>
                            </span>
                        </td>
                        <td><?= $n['periodo'] ?></td>
                        <td><?= $n['observacion'] ?? '—' ?></td>
                        <td>
                            <div class="d-flex gap-1">
                                <button class="btn btn-sm btn-outline-primary"
                                    onclick="abrirEditar(<?= $n['id'] ?>, <?= $n['nota'] ?>, '<?= addslashes($n['observacion']) ?>')">
                                    ✏️
                                </button>
                                <form method="POST" onsubmit="return confirm('¿Eliminar esta nota?')">
                                    <input type="hidden" name="accion" value="eliminar">
                                    <input type="hidden" name="nota_id" value="<?= $n['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger">🗑️</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    <?php if (!$hay): ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted">Sin notas registradas</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Editar Nota -->
<div class="modal fade" id="modalEditar" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(135deg, #1e293b, #0f172a); color:white;">
                <h5 class="modal-title">✏️ Editar Nota</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="accion" value="editar">
                <input type="hidden" name="nota_id" id="edit_id">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Nueva nota (0-10)</label>
                        <input type="number" name="nota" id="edit_nota" class="form-control"
                               min="0" max="10" step="0.1" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Observación</label>
                        <input type="text" name="observacion" id="edit_obs" class="form-control"
                               placeholder="Opcional">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar cambios</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/asistente.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function abrirEditar(id, nota, observacion) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_nota').value = nota;
    document.getElementById('edit_obs').value = observacion;
    new bootstrap.Modal(document.getElementById('modalEditar')).show();
}
</script>
</body>
</html>