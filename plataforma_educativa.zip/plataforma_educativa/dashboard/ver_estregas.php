<?php
session_start();
include '../includes/conexion.php';
 include '../includes/asistente.php';
if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'profesor') {
    header("Location: ../index.php");
    exit();
}

$actividad_id = $_GET['id'];
$mensaje = "";

// Calificar entrega
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $entrega_id = $_POST['entrega_id'];
    $calificacion = $_POST['calificacion'];

    $sql = "UPDATE entregas SET calificacion=$calificacion, estado='entregado' WHERE id=$entrega_id";
    if (mysqli_query($conexion, $sql)) {
        $mensaje = "✅ Calificación guardada";
    }
}

// Datos de la actividad
$sql_act = "SELECT a.*, m.nombre as materia, m.grado FROM actividades a
            JOIN materias m ON a.materia_id = m.id
            WHERE a.id=$actividad_id";
$res_act = mysqli_query($conexion, $sql_act);
$actividad = mysqli_fetch_assoc($res_act);

// Entregas
$sql_ent = "SELECT e.*, u.nombre as estudiante FROM entregas e
            JOIN usuarios u ON e.estudiante_id = u.id
            WHERE e.actividad_id=$actividad_id
            ORDER BY e.created_at DESC";
$entregas = mysqli_query($conexion, $sql_ent);

// Estudiantes que NO han entregado
$sql_no_ent = "SELECT u.id, u.nombre FROM usuarios u
               WHERE u.rol='estudiante' AND u.grado='{$actividad['grado']}'
               AND u.id NOT IN (SELECT estudiante_id FROM entregas WHERE actividad_id=$actividad_id)";
$no_entregaron = mysqli_query($conexion, $sql_no_ent);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Entregas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<nav class="navbar navbar-dark bg-primary">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="profesor.php">
            <img src="../assets/logo.png" alt="Logo"> Colegio José Antonio Galán
        </a>
        <div class="ms-auto d-flex gap-2">
            <a href="actividades.php" class="btn btn-outline-light btn-sm">⬅ Volver</a>
            <a href="../cerrar_sesion.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-4">

    <!-- Info actividad -->
    <div class="card shadow-sm mb-4 border-0 bg-info text-white">
        <div class="card-body">
            <h4 class="fw-bold">📁 <?= $actividad['titulo'] ?></h4>
            <p class="mb-0"><?= $actividad['descripcion'] ?></p>
            <small>📚 <?= $actividad['materia'] ?> — 🎓 <?= $actividad['grado'] ?> — 
                   📅 Límite: <?= date('d/m/Y', strtotime($actividad['fecha_limite'])) ?></small>
        </div>
    </div>

    <?php if ($mensaje): ?>
        <div class="alert alert-success"><?= $mensaje ?></div>
    <?php endif; ?>

    <!-- Entregas recibidas -->
    <h5 class="fw-bold mb-3">📬 Entregas Recibidas</h5>
    <?php if (mysqli_num_rows($entregas) == 0): ?>
        <div class="alert alert-info">Sin entregas aún</div>
    <?php else: ?>
        <div class="table-responsive mb-4">
            <table class="table table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Estudiante</th>
                        <th>Archivo</th>
                        <th>Fecha entrega</th>
                        <th>Calificación</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($e = mysqli_fetch_assoc($entregas)): ?>
                    <tr>
                        <td><strong><?= $e['estudiante'] ?></strong></td>
                        <td>
                            <a href="../uploads/entregas/<?= $e['archivo'] ?>" 
                               target="_blank" class="btn btn-sm btn-outline-info">
                                📎 Ver archivo
                            </a>
                        </td>
                        <td><?= date('d/m/Y H:i', strtotime($e['created_at'])) ?></td>
                        <td>
                            <?php if ($e['calificacion']): ?>
                                <span class="badge fs-6 <?= $e['calificacion'] >= 6 ? 'bg-success' : 'bg-danger' ?>">
                                    <?= $e['calificacion'] ?>
                                </span>
                            <?php else: ?>
                                <span class="text-muted">Sin calificar</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <form method="POST" class="d-flex gap-2 align-items-center">
                                <input type="hidden" name="entrega_id" value="<?= $e['id'] ?>">
                                <input type="number" name="calificacion" class="form-control form-control-sm" 
                                       style="width:80px" min="0" max="10" step="0.1"
                                       value="<?= $e['calificacion'] ?>">
                                <button type="submit" class="btn btn-sm btn-success">✔</button>
                            </form>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    <!-- Sin entregar -->
    <h5 class="fw-bold mb-3 text-danger">❌ Sin Entregar</h5>
    <?php if (mysqli_num_rows($no_entregaron) == 0): ?>
        <div class="alert alert-success">✅ Todos entregaron</div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="table-dark">
                    <tr><th>Estudiante</th><th>Estado</th></tr>
                </thead>
                <tbody>
                    <?php while ($ne = mysqli_fetch_assoc($no_entregaron)): ?>
                    <tr>
                        <td><?= $ne['nombre'] ?></td>
                        <td><span class="badge bg-danger">❌ Pendiente</span></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>