<?php
session_start();
include '../includes/conexion.php';
 include '../includes/asistente.php';
if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'profesor') {
    header("Location: ../index.php");
    exit();
}

// Contar estudiantes
$sql_est = "SELECT COUNT(*) as total FROM usuarios WHERE rol='estudiante'";
$res_est = mysqli_query($conexion, $sql_est);
$total_est = mysqli_fetch_assoc($res_est)['total'];

// Contar notas registradas hoy
$sql_notas = "SELECT COUNT(*) as total FROM notas WHERE DATE(created_at) = CURDATE()";
$res_notas = mysqli_query($conexion, $sql_notas);
$total_notas = mysqli_fetch_assoc($res_notas)['total'];

// Contar asistencias registradas hoy
$sql_asist = "SELECT COUNT(*) as total FROM asistencia WHERE fecha = CURDATE()";
$res_asist = mysqli_query($conexion, $sql_asist);
$total_asist = mysqli_fetch_assoc($res_asist)['total'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Profesor — José Antonio Galán</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="#">
            <img src="../assets/logo.png" alt="Logo"> Colegio José Antonio Galán
        </a>
        <div class="ms-auto d-flex align-items-center gap-3">
            <span class="text-white small">👤 <?= $_SESSION['nombre'] ?></span>
            <a href="../cerrar_sesion.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-4">

    <div class="mb-4">
        <h4 class="fw-bold">Bienvenido, <?= $_SESSION['nombre'] ?> 👋</h4>
        <p class="text-muted">Panel de control — <?= date('d/m/Y') ?></p>
    </div>

    <!-- Tarjetas resumen -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card shadow-sm p-3 d-flex flex-row align-items-center gap-3">
                <div class="fs-1">🎓</div>
                <div>
                    <h3 class="mb-0 fw-bold text-primary"><?= $total_est ?></h3>
                    <p class="mb-0 text-muted small">Estudiantes registrados</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm p-3 d-flex flex-row align-items-center gap-3">
                <div class="fs-1">📊</div>
                <div>
                    <h3 class="mb-0 fw-bold text-success"><?= $total_notas ?></h3>
                    <p class="mb-0 text-muted small">Notas registradas hoy</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm p-3 d-flex flex-row align-items-center gap-3">
                <div class="fs-1">✅</div>
                <div>
                    <h3 class="mb-0 fw-bold text-warning"><?= $total_asist ?></h3>
                    <p class="mb-0 text-muted small">Asistencias registradas hoy</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Módulos -->
    <h5 class="fw-bold mb-3">Módulos</h5>
    <div class="row g-4">
        <div class="col-md-3">
            <div class="card text-center shadow-sm h-100 p-2">
                <div class="card-body">
                    <div class="fs-1 mb-2">📊</div>
                    <h5 class="card-title fw-bold">Notas</h5>
                    <p class="card-text text-muted small">Registra y gestiona calificaciones</p>
                    <a href="notas.php" class="btn btn-primary btn-sm w-100">Ir a Notas</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm h-100 p-2">
                <div class="card-body">
                    <div class="fs-1 mb-2">✅</div>
                    <h5 class="card-title fw-bold">Asistencia</h5>
                    <p class="card-text text-muted small">Toma y revisa asistencia diaria</p>
                    <a href="asistencia.php" class="btn btn-success btn-sm w-100">Ir a Asistencia</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm h-100 p-2">
                <div class="card-body">
                    <div class="fs-1 mb-2">📋</div>
                    <h5 class="card-title fw-bold">Formativos</h5>
                    <p class="card-text text-muted small">Registra llamados y citaciones</p>
                    <a href="formativos.php" class="btn btn-warning btn-sm w-100">Ir a Formativos</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm h-100 p-2">
                <div class="card-body">
                    <div class="fs-1 mb-2">📁</div>
                    <h5 class="card-title fw-bold">Actividades</h5>
                    <p class="card-text text-muted small">Sube y revisa actividades</p>
                    <a href="actividades.php" class="btn btn-info btn-sm w-100">Ir a Actividades</a>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>