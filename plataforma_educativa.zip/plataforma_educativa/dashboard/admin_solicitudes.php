<?php
session_start();
include '../includes/conexion.php';

if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'administrador') {
    header("Location: ../index.php");
    exit();
}

$mensaje = "";

// Cambiar contraseña por solicitud
if (isset($_POST['accion']) && $_POST['accion'] == 'cambiar_pass_solicitud') {
    $usuario_id = $_POST['usuario_id'];
    $solicitud_id = $_POST['solicitud_id'];
    $nueva_pass = password_hash($_POST['nueva_password'], PASSWORD_DEFAULT);

    mysqli_query($conexion, "UPDATE usuarios SET password='$nueva_pass' WHERE id=$usuario_id");
    mysqli_query($conexion, "UPDATE recuperacion_password SET estado='atendido' WHERE id=$solicitud_id");

    $sql_notif = "INSERT INTO notificaciones (usuario_id, titulo, mensaje, tipo) 
                  VALUES ($usuario_id, '🔑 Contraseña actualizada', 
                  'Tu contraseña fue cambiada por el administrador. Ya puedes iniciar sesión.', 'nota')";
    mysqli_query($conexion, $sql_notif);
    $mensaje = "✅ Contraseña cambiada y usuario notificado";
}

// Rechazar solicitud
if (isset($_POST['accion']) && $_POST['accion'] == 'rechazar') {
    $solicitud_id = $_POST['solicitud_id'];
    $usuario_id = $_POST['usuario_id'];
    mysqli_query($conexion, "UPDATE recuperacion_password SET estado='atendido' WHERE id=$solicitud_id");

    $sql_notif = "INSERT INTO notificaciones (usuario_id, titulo, mensaje, tipo) 
                  VALUES ($usuario_id, '🔑 Solicitud rechazada', 
                  'Tu solicitud de cambio de contraseña fue rechazada. Contacta al administrador.', 'nota')";
    mysqli_query($conexion, $sql_notif);
    $mensaje = "✅ Solicitud rechazada";
}

// Solicitudes pendientes
$sql_pendientes = "SELECT r.*, u.nombre, u.email, u.rol, u.grado FROM recuperacion_password r
                   JOIN usuarios u ON r.usuario_id = u.id
                   WHERE r.estado='pendiente'
                   ORDER BY r.created_at DESC";
$pendientes = mysqli_query($conexion, $sql_pendientes);
$total_pendientes = mysqli_num_rows($pendientes);

// Solicitudes atendidas
$sql_atendidas = "SELECT r.*, u.nombre, u.email, u.rol FROM recuperacion_password r
                  JOIN usuarios u ON r.usuario_id = u.id
                  WHERE r.estado='atendido'
                  ORDER BY r.created_at DESC LIMIT 20";
$atendidas = mysqli_query($conexion, $sql_atendidas);
$total_atendidas = mysqli_fetch_assoc(mysqli_query($conexion, "SELECT COUNT(*) as t FROM recuperacion_password WHERE estado='atendido'"))['t'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solicitudes de Contraseña — Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<nav class="navbar navbar-dark" style="background: linear-gradient(135deg, #1e293b, #0f172a);">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="admin.php">
            <img src="../assets/logo.png" alt="Logo"> Colegio José Antonio Galán
        </a>
        <div class="ms-auto d-flex gap-2">
            <a href="admin.php" class="btn btn-outline-light btn-sm">⬅ Volver</a>
            <a href="../cerrar_sesion.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h4 class="fw-bold mb-4">🔑 Solicitudes de Recuperación de Contraseña</h4>

    <?php if ($mensaje): ?>
        <div class="alert alert-success"><?= $mensaje ?></div>
    <?php endif; ?>

    <!-- Resumen -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card text-center shadow-sm border-0 p-3">
                <div class="fs-1">⏳</div>
                <h3 class="fw-bold text-danger"><?= $total_pendientes ?></h3>
                <small class="text-muted">Pendientes</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm border-0 p-3">
                <div class="fs-1">✅</div>
                <h3 class="fw-bold text-success"><?= $total_atendidas ?></h3>
                <small class="text-muted">Atendidas</small>
            </div>
        </div>
    </div>

    <!-- Tabs -->
    <ul class="nav nav-tabs mb-4">
        <li class="nav-item">
            <a class="nav-link active" data-bs-toggle="tab" href="#pendientes">
                ⏳ Pendientes
                <?php if ($total_pendientes > 0): ?>
                    <span class="badge bg-danger"><?= $total_pendientes ?></span>
                <?php endif; ?>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#atendidas">
                ✅ Atendidas
            </a>
        </li>
    </ul>

    <div class="tab-content">

        <!-- Tab pendientes -->
        <div class="tab-pane fade show active" id="pendientes">
            <?php if ($total_pendientes == 0): ?>
                <div class="alert alert-success">✅ No hay solicitudes pendientes</div>
            <?php else: ?>
                <?php while ($s = mysqli_fetch_assoc($pendientes)): ?>
                <div class="card shadow-sm mb-3 border-0 border-start border-danger border-4">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h5 class="fw-bold mb-1">👤 <?= $s['nombre'] ?></h5>
                                <p class="text-muted mb-0 small">📧 <?= $s['email'] ?></p>
                                <span class="badge bg-primary"><?= ucfirst($s['rol']) ?></span>
                                <?php if ($s['grado']): ?>
                                    <span class="badge bg-success"><?= $s['grado'] ?></span>
                                <?php endif; ?>
                                <br>
                                <small class="text-muted">
                                    📅 Solicitado: <?= date('d/m/Y H:i', strtotime($s['created_at'])) ?>
                                </small>
                            </div>
                            <div class="col-md-6 text-end d-flex gap-2 justify-content-end">
                                <button class="btn btn-warning btn-sm"
                                    onclick="abrirPass(<?= $s['usuario_id'] ?>, '<?= addslashes($s['nombre']) ?>', <?= $s['id'] ?>)">
                                    🔑 Cambiar contraseña
                                </button>
                                <form method="POST">
                                    <input type="hidden" name="accion" value="rechazar">
                                    <input type="hidden" name="solicitud_id" value="<?= $s['id'] ?>">
                                    <input type="hidden" name="usuario_id" value="<?= $s['usuario_id'] ?>">
                                    <button type="submit" class="btn btn-outline-danger btn-sm"
                                            onclick="return confirm('¿Rechazar esta solicitud?')">
                                        ❌ Rechazar
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php endif; ?>
        </div>

        <!-- Tab atendidas -->
        <div class="tab-pane fade" id="atendidas">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>Usuario</th>
                            <th>Email</th>
                            <th>Rol</th>
                            <th>Fecha solicitud</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $hay = false;
                        while ($a = mysqli_fetch_assoc($atendidas)):
                            $hay = true;
                        ?>
                        <tr>
                            <td><strong><?= $a['nombre'] ?></strong></td>
                            <td><?= $a['email'] ?></td>
                            <td><span class="badge bg-primary"><?= ucfirst($a['rol']) ?></span></td>
                            <td><?= date('d/m/Y H:i', strtotime($a['created_at'])) ?></td>
                            <td><span class="badge bg-success">✅ Atendida</span></td>
                        </tr>
                        <?php endwhile; ?>
                        <?php if (!$hay): ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted">Sin solicitudes atendidas</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<!-- Modal cambiar contraseña -->
<div class="modal fade" id="modalPass" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-warning text-dark">
                <h5 class="modal-title">🔑 Cambiar Contraseña</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="accion" value="cambiar_pass_solicitud">
                <input type="hidden" name="usuario_id" id="pass_usuario_id">
                <input type="hidden" name="solicitud_id" id="pass_sol_id">
                <div class="modal-body">
                    <p>Cambiando contraseña de: <strong id="pass_nombre"></strong></p>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Nueva contraseña</label>
                        <input type="password" name="nueva_password" class="form-control"
                               placeholder="Mínimo 6 caracteres" required minlength="6">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-warning">Cambiar contraseña</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/asistente.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function abrirPass(usuarioId, nombre, solicitudId) {
    document.getElementById('pass_usuario_id').value = usuarioId;
    document.getElementById('pass_nombre').textContent = nombre;
    document.getElementById('pass_sol_id').value = solicitudId;
    new bootstrap.Modal(document.getElementById('modalPass')).show();
}
</script>
</body>
</html>