<?php
session_start();
include '../includes/conexion.php';
 include '../includes/asistente.php';
if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'profesor') {
    header("Location: ../index.php");
    exit();
}

$profesor_id = $_SESSION['id'];
$mensaje = "";
$error = "";

// Guardar formativo
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $estudiante_id = $_POST['estudiante_id'];
    $tipo = $_POST['tipo'];
    $descripcion = $_POST['descripcion'];
    $afecta_nota = $_POST['afecta_nota'];
    $fecha = $_POST['fecha'];

    $sql = "INSERT INTO formativos (estudiante_id, profesor_id, tipo, descripcion, afecta_nota, fecha) 
            VALUES ($estudiante_id, $profesor_id, '$tipo', '$descripcion', $afecta_nota, '$fecha')";

    if (mysqli_query($conexion, $sql)) {
        // Notificación al estudiante
        $titulo = "Nuevo formativo registrado";
        $tipo_texto = match($tipo) {
            'llamado_escrito' => 'Llamado Escrito',
            'citacion_padres' => 'Citación a Padres',
            'suspension'      => 'Suspensión',
            default           => $tipo
        };
        $msg_notif = "Se ha registrado un formativo: $tipo_texto";
        $sql_notif = "INSERT INTO notificaciones (usuario_id, titulo, mensaje, tipo) 
                      VALUES ($estudiante_id, '$titulo', '$msg_notif', 'nota')";
        mysqli_query($conexion, $sql_notif);
        $mensaje = "✅ Formativo registrado correctamente";
    } else {
        $error = "❌ Error al registrar el formativo";
    }
}

// Filtros
$grado_filtro = isset($_GET['grado']) ? $_GET['grado'] : '';

if ($grado_filtro) {
    $sql_estudiantes = "SELECT id, nombre FROM usuarios WHERE rol='estudiante' AND grado='$grado_filtro' ORDER BY nombre";
} else {
    $sql_estudiantes = "SELECT id, nombre FROM usuarios WHERE rol='estudiante' ORDER BY nombre";
}
$estudiantes = mysqli_query($conexion, $sql_estudiantes);

// Formativos registrados
if ($grado_filtro) {
    $sql_formativos = "SELECT f.*, u.nombre as estudiante, u.grado FROM formativos f
                       JOIN usuarios u ON f.estudiante_id = u.id
                       WHERE f.profesor_id=$profesor_id AND u.grado='$grado_filtro'
                       ORDER BY f.fecha DESC";
} else {
    $sql_formativos = "SELECT f.*, u.nombre as estudiante, u.grado FROM formativos f
                       JOIN usuarios u ON f.estudiante_id = u.id
                       WHERE f.profesor_id=$profesor_id
                       ORDER BY f.fecha DESC";
}
$lista_formativos = mysqli_query($conexion, $sql_formativos);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formativos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<nav class="navbar navbar-dark bg-primary">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="profesor.php">
            <img src="../assets/logo.png" alt="Logo"> Colegio José Antonio Galán
        </a>
        <div class="ms-auto d-flex gap-2">
            <a href="profesor.php" class="btn btn-outline-light btn-sm">⬅ Volver</a>
            <a href="../cerrar_sesion.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h4 class="fw-bold mb-4">📋 Gestión de Formativos</h4>

    <?php if ($mensaje): ?>
        <div class="alert alert-success"><?= $mensaje ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <!-- Filtro por grado -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-secondary text-white">🎓 Seleccionar Grado</div>
        <div class="card-body">
            <form method="GET">
                <div class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label class="form-label">Grado</label>
                        <select name="grado" class="form-select" onchange="this.form.submit()">
                            <option value="">Todos los grados</option>
                            <option value="Grado 6"  <?= $grado_filtro=='Grado 6'  ? 'selected' : '' ?>>Grado 6</option>
                            <option value="Grado 7"  <?= $grado_filtro=='Grado 7'  ? 'selected' : '' ?>>Grado 7</option>
                            <option value="Grado 8"  <?= $grado_filtro=='Grado 8'  ? 'selected' : '' ?>>Grado 8</option>
                            <option value="Grado 9"  <?= $grado_filtro=='Grado 9'  ? 'selected' : '' ?>>Grado 9</option>
                            <option value="Grado 10" <?= $grado_filtro=='Grado 10' ? 'selected' : '' ?>>Grado 10</option>
                            <option value="Grado 11" <?= $grado_filtro=='Grado 11' ? 'selected' : '' ?>>Grado 11</option>
                        </select>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Formulario registrar formativo -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-warning text-dark fw-bold">
            📝 Registrar Formativo
        </div>
        <div class="card-body">
            <form method="POST">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Estudiante</label>
                        <select name="estudiante_id" class="form-select" required>
                            <option value="">Seleccionar...</option>
                            <?php while ($e = mysqli_fetch_assoc($estudiantes)): ?>
                                <option value="<?= $e['id'] ?>"><?= $e['nombre'] ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-semibold">Tipo de Formativo</label>
                        <select name="tipo" class="form-select" required>
                            <option value="">Seleccionar...</option>
                            <option value="llamado_escrito">Llamado Escrito</option>
                            <option value="citacion_padres">Citación a Padres</option>
                            <option value="suspension">Suspensión</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label fw-semibold">Afecta Nota</label>
                        <input type="number" name="afecta_nota" class="form-control" 
                               min="0" max="5" step="0.1" value="0">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-semibold">Fecha</label>
                        <input type="date" name="fecha" class="form-control" 
                               value="<?= date('Y-m-d') ?>" required>
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-semibold">Descripción</label>
                        <textarea name="descripcion" class="form-control" rows="3" 
                                  placeholder="Describe el motivo del formativo..." required></textarea>
                    </div>
                </div>
                <button type="submit" class="btn btn-warning mt-3">
                    💾 Guardar Formativo
                </button>
            </form>
        </div>
    </div>

    <!-- Lista de formativos -->
    <div class="card shadow-sm">
        <div class="card-header bg-secondary text-white fw-bold">
            📋 Formativos Registrados <?= $grado_filtro ? "— $grado_filtro" : "" ?>
        </div>
        <div class="card-body table-responsive">
            <table class="table table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Estudiante</th>
                        <th>Grado</th>
                        <th>Tipo</th>
                        <th>Descripción</th>
                        <th>Afecta Nota</th>
                        <th>Estado</th>
                        <th>Fecha</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $hay_formativos = false;
                    while ($f = mysqli_fetch_assoc($lista_formativos)):
                        $hay_formativos = true;
                        $color = match($f['tipo']) {
                            'llamado_escrito' => 'warning',
                            'citacion_padres' => 'info',
                            'suspension'      => 'danger',
                            default           => 'secondary'
                        };
                        $tipo_texto = match($f['tipo']) {
                            'llamado_escrito' => 'Llamado Escrito',
                            'citacion_padres' => 'Citación a Padres',
                            'suspension'      => 'Suspensión',
                            default           => $f['tipo']
                        };
                    ?>
                    <tr>
                        <td><strong><?= $f['estudiante'] ?></strong></td>
                        <td><?= $f['grado'] ?></td>
                        <td>
                            <span class="badge bg-<?= $color ?>
                                <?= $color == 'warning' ? 'text-dark' : '' ?>">
                                <?= $tipo_texto ?>
                            </span>
                        </td>
                        <td><?= strlen($f['descripcion']) > 50 
                            ? substr($f['descripcion'], 0, 50) . '...' 
                            : $f['descripcion'] ?></td>
                        <td>
                            <?php if ($f['afecta_nota'] > 0): ?>
                                <span class="badge bg-danger">-<?= $f['afecta_nota'] ?></span>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge <?= $f['firmado'] == 'firmado' ? 'bg-success' : 'bg-secondary' ?>">
                                <?= $f['firmado'] == 'firmado' ? '✅ Firmado' : '⏳ Pendiente' ?>
                            </span>
                        </td>
                        <td><?= date('d/m/Y', strtotime($f['fecha'])) ?></td>
                    </tr>
                    <?php endwhile; ?>
                    <?php if (!$hay_formativos): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted">
                                Sin formativos registrados
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>