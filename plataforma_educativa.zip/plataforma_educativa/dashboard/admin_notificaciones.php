<?php
session_start();
include '../includes/conexion.php';

if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'administrador') {
    header("Location: ../index.php");
    exit();
}

$mensaje = "";
$error = "";

// Enviar notificación
if (isset($_POST['accion']) && $_POST['accion'] == 'enviar') {
    $titulo = $_POST['titulo'];
    $mensaje_notif = $_POST['mensaje'];
    $tipo = $_POST['tipo'];
    $destinatario = $_POST['destinatario'];

    // Determinar a quiénes enviar
    if ($destinatario == 'todos') {
        $sql_dest = "SELECT id FROM usuarios WHERE rol IN ('estudiante', 'profesor')";
    } elseif ($destinatario == 'estudiantes') {
        $sql_dest = "SELECT id FROM usuarios WHERE rol='estudiante'";
    } elseif ($destinatario == 'profesores') {
        $sql_dest = "SELECT id FROM usuarios WHERE rol='profesor'";
    } else {
        $sql_dest = "SELECT id FROM usuarios WHERE id=" . intval($destinatario);
    }

    $res_dest = mysqli_query($conexion, $sql_dest);
    $enviados = 0;

    while ($d = mysqli_fetch_assoc($res_dest)) {
        $sql_notif = "INSERT INTO notificaciones (usuario_id, titulo, mensaje, tipo) 
                      VALUES ({$d['id']}, '$titulo', '$mensaje_notif', '$tipo')";
        if (mysqli_query($conexion, $sql_notif)) $enviados++;
    }

    $mensaje = "✅ Notificación enviada a $enviados usuario(s)";
}

// Eliminar notificación
if (isset($_POST['accion']) && $_POST['accion'] == 'eliminar') {
    $notif_id = $_POST['notif_id'];
    mysqli_query($conexion, "DELETE FROM notificaciones WHERE id=$notif_id");
    $mensaje = "✅ Notificación eliminada";
}

// Obtener usuarios para destinatario individual
$sql_usuarios = "SELECT id, nombre, rol FROM usuarios WHERE rol IN ('estudiante','profesor') ORDER BY rol, nombre";
$usuarios = mysqli_query($conexion, $sql_usuarios);

// Historial de notificaciones
$sql_historial = "SELECT n.*, u.nombre as destinatario, u.rol FROM notificaciones n
                  JOIN usuarios u ON n.usuario_id = u.id
                  ORDER BY n.created_at DESC LIMIT 50";
$historial = mysqli_query($conexion, $sql_historial);

// Conteo
$total_notif = mysqli_fetch_assoc(mysqli_query($conexion, "SELECT COUNT(*) as t FROM notificaciones"))['t'];
$no_leidas = mysqli_fetch_assoc(mysqli_query($conexion, "SELECT COUNT(*) as t FROM notificaciones WHERE leido=0"))['t'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notificaciones — Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<nav class="navbar navbar-dark" style="background: linear-gradient(135deg, #1e293b, #0f172a);">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="admin.php">
            <img src="../assets/logo.png" alt="Logo"> Colegio José Antonio Galán
        </a>
        <div class="ms-auto d-flex gap-2">
            <a href="admin.php" class="btn btn-outline-light btn-sm">⬅ Volver</a>
            <a href="../cerrar_sesion.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h4 class="fw-bold mb-4">🔔 Gestión de Notificaciones</h4>

    <?php if ($mensaje): ?>
        <div class="alert alert-success"><?= $mensaje ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <!-- Resumen -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card text-center shadow-sm border-0 p-3">
                <div class="fs-1">🔔</div>
                <h3 class="fw-bold text-primary"><?= $total_notif ?></h3>
                <small class="text-muted">Total enviadas</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm border-0 p-3">
                <div class="fs-1">📬</div>
                <h3 class="fw-bold text-danger"><?= $no_leidas ?></h3>
                <small class="text-muted">Sin leer</small>
            </div>
        </div>
    </div>

    <!-- Tabs -->
    <ul class="nav nav-tabs mb-4">
        <li class="nav-item">
            <a class="nav-link active" data-bs-toggle="tab" href="#enviar">📤 Enviar Notificación</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#historial">📋 Historial</a>
        </li>
    </ul>

    <div class="tab-content">

        <!-- Tab enviar -->
        <div class="tab-pane fade show active" id="enviar">
            <div class="card shadow-sm">
                <div class="card-header fw-bold" style="background: linear-gradient(135deg, #1e293b, #0f172a); color:white;">
                    📤 Nueva Notificación
                </div>
                <div class="card-body">
                    <form method="POST">
                        <input type="hidden" name="accion" value="enviar">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Título</label>
                                <input type="text" name="titulo" class="form-control"
                                       placeholder="Título de la notificación" required>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-semibold">Tipo</label>
                                <select name="tipo" class="form-select" required>
                                    <option value="nota">📊 Nota</option>
                                    <option value="actividad">📁 Actividad</option>
                                    <option value="vencimiento">⏰ Vencimiento</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-semibold">Destinatario</label>
                                <select name="destinatario" class="form-select" required>
                                    <option value="todos">👥 Todos</option>
                                    <option value="estudiantes">🎓 Solo estudiantes</option>
                                    <option value="profesores">👨‍🏫 Solo profesores</option>
                                    <optgroup label="Usuario específico">
                                        <?php while ($u = mysqli_fetch_assoc($usuarios)): ?>
                                            <option value="<?= $u['id'] ?>">
                                                <?= $u['nombre'] ?> (<?= ucfirst($u['rol']) ?>)
                                            </option>
                                        <?php endwhile; ?>
                                    </optgroup>
                                </select>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold">Mensaje</label>
                                <textarea name="mensaje" class="form-control" rows="4"
                                          placeholder="Escribe el mensaje..." required></textarea>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-warning mt-3">
                            📤 Enviar Notificación
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Tab historial -->
        <div class="tab-pane fade" id="historial">
            <div class="card shadow-sm">
                <div class="card-header fw-bold" style="background: linear-gradient(135deg, #1e293b, #0f172a); color:white;">
                    📋 Historial de Notificaciones
                </div>
                <div class="card-body table-responsive">
                    <table class="table table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Destinatario</th>
                                <th>Rol</th>
                                <th>Título</th>
                                <th>Mensaje</th>
                                <th>Tipo</th>
                                <th>Estado</th>
                                <th>Fecha</th>
                                <th>Acción</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $hay = false;
                            while ($n = mysqli_fetch_assoc($historial)):
                                $hay = true;
                                $icono = match($n['tipo']) {
                                    'nota'        => '📊',
                                    'actividad'   => '📁',
                                    'vencimiento' => '⏰',
                                    default       => '🔔'
                                };
                                $color_rol = match($n['rol']) {
                                    'estudiante' => 'primary',
                                    'profesor'   => 'success',
                                    default      => 'secondary'
                                };
                            ?>
                            <tr>
                                <td><strong><?= $n['destinatario'] ?></strong></td>
                                <td><span class="badge bg-<?= $color_rol ?>"><?= ucfirst($n['rol']) ?></span></td>
                                <td><?= $n['titulo'] ?></td>
                                <td><small><?= strlen($n['mensaje']) > 40 ? substr($n['mensaje'],0,40).'...' : $n['mensaje'] ?></small></td>
                                <td><?= $icono ?></td>
                                <td>
                                    <span class="badge <?= $n['leido'] ? 'bg-success' : 'bg-danger' ?>">
                                        <?= $n['leido'] ? '✅ Leída' : '📬 Sin leer' ?>
                                    </span>
                                </td>
                                <td><small><?= date('d/m/Y H:i', strtotime($n['created_at'])) ?></small></td>
                                <td>
                                    <form method="POST">
                                        <input type="hidden" name="accion" value="eliminar">
                                        <input type="hidden" name="notif_id" value="<?= $n['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger"
                                                onclick="return confirm('¿Eliminar esta notificación?')">
                                            🗑️
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                            <?php if (!$hay): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted">Sin notificaciones</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>

<?php include '../includes/asistente.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>