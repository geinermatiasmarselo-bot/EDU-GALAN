<?php
session_start();
include '../includes/conexion.php';
 include '../includes/asistente.php';
if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'estudiante') {
    header("Location: ../index.php");
    exit();
}

$estudiante_id = $_SESSION['id'];

// Datos del estudiante
$sql_est = "SELECT * FROM usuarios WHERE id=$estudiante_id";
$res_est = mysqli_query($conexion, $sql_est);
$estudiante = mysqli_fetch_assoc($res_est);

// Filtro por mes
$mes_filtro = isset($_GET['mes']) ? $_GET['mes'] : date('Y-m');

// Asistencia del mes
$sql_asistencia = "SELECT * FROM asistencia 
                   WHERE estudiante_id=$estudiante_id 
                   AND DATE_FORMAT(fecha, '%Y-%m') = '$mes_filtro'
                   ORDER BY fecha DESC";
$res_asistencia = mysqli_query($conexion, $sql_asistencia);

$registros = [];
while ($a = mysqli_fetch_assoc($res_asistencia)) {
    $registros[] = $a;
}

// Conteo total
$sql_total = "SELECT 
    SUM(CASE WHEN estado='presente' THEN 1 ELSE 0 END) as presentes,
    SUM(CASE WHEN estado='ausente' THEN 1 ELSE 0 END) as ausentes,
    SUM(CASE WHEN estado='tardanza' THEN 1 ELSE 0 END) as tardanzas,
    COUNT(*) as total
    FROM asistencia WHERE estudiante_id=$estudiante_id";
$res_total = mysqli_query($conexion, $sql_total);
$totales = mysqli_fetch_assoc($res_total);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Asistencia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<nav class="navbar navbar-dark bg-success">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="estudiante.php">🏫 Plataforma Educativa</a>
        <div class="ms-auto d-flex gap-2">
            <a href="estudiante.php" class="btn btn-outline-light btn-sm">⬅ Volver</a>
            <a href="../cerrar_sesion.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-4">

    <!-- Info estudiante -->
    <div class="card shadow-sm mb-4 border-0">
        <div class="card-body d-flex align-items-center gap-3">
            <div class="fs-1">👤</div>
            <div>
                <h4 class="mb-0"><?= $estudiante['nombre'] ?></h4>
                <span class="badge bg-success"><?= $estudiante['grado'] ?></span>
            </div>
        </div>
    </div>

    <h4 class="mb-4">✅ Mi Asistencia</h4>

    <!-- Tarjetas resumen total -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card text-center border-0 shadow-sm">
                <div class="card-body">
                    <div class="fs-1">📅</div>
                    <h3 class="text-primary"><?= $totales['total'] ?? 0 ?></h3>
                    <p class="text-muted mb-0">Total días</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center border-0 shadow-sm">
                <div class="card-body">
                    <div class="fs-1">✅</div>
                    <h3 class="text-success"><?= $totales['presentes'] ?? 0 ?></h3>
                    <p class="text-muted mb-0">Presentes</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center border-0 shadow-sm">
                <div class="card-body">
                    <div class="fs-1">❌</div>
                    <h3 class="text-danger"><?= $totales['ausentes'] ?? 0 ?></h3>
                    <p class="text-muted mb-0">Ausentes</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center border-0 shadow-sm">
                <div class="card-body">
                    <div class="fs-1">⏰</div>
                    <h3 class="text-warning"><?= $totales['tardanzas'] ?? 0 ?></h3>
                    <p class="text-muted mb-0">Tardanzas</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Filtro por mes -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <form method="GET">
                <div class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label class="form-label">Filtrar por mes</label>
                        <input type="month" name="mes" class="form-control" 
                               value="<?= $mes_filtro ?>" onchange="this.form.submit()">
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabla de asistencia -->
    <div class="card shadow-sm">
        <div class="card-header bg-success text-white">
            📋 Registro — <?= date('F Y', strtotime($mes_filtro . '-01')) ?>
        </div>
        <div class="card-body table-responsive">
            <table class="table table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Fecha</th>
                        <th>Día</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($registros)): ?>
                        <tr>
                            <td colspan="3" class="text-center text-muted">
                                Sin registros para este mes
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($registros as $r): 
                            $color = match($r['estado']) {
                                'presente' => 'success',
                                'ausente'  => 'danger',
                                'tardanza' => 'warning',
                                default    => 'secondary'
                            };
                            $icono = match($r['estado']) {
                                'presente' => '✅',
                                'ausente'  => '❌',
                                'tardanza' => '⏰',
                                default    => '❓'
                            };
                        ?>
                        <tr>
                            <td><?= date('d/m/Y', strtotime($r['fecha'])) ?></td>
                            <td><?= strftime('%A', strtotime($r['fecha'])) ?></td>
                            <td>
                                <span class="badge bg-<?= $color ?>">
                                    <?= $icono ?> <?= ucfirst($r['estado']) ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>