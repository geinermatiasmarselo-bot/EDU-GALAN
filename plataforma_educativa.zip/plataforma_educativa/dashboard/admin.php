<?php
session_start();
include '../includes/conexion.php';

if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'administrador') {
    header("Location: ../index.php");
    exit();
}

// Estadísticas generales
$total_estudiantes = mysqli_fetch_assoc(mysqli_query($conexion, "SELECT COUNT(*) as t FROM usuarios WHERE rol='estudiante'"))['t'];
$total_profesores = mysqli_fetch_assoc(mysqli_query($conexion, "SELECT COUNT(*) as t FROM usuarios WHERE rol='profesor'"))['t'];
$total_notas = mysqli_fetch_assoc(mysqli_query($conexion, "SELECT COUNT(*) as t FROM notas"))['t'];
$total_formativos = mysqli_fetch_assoc(mysqli_query($conexion, "SELECT COUNT(*) as t FROM formativos"))['t'];
$total_actividades = mysqli_fetch_assoc(mysqli_query($conexion, "SELECT COUNT(*) as t FROM actividades"))['t'];
$promedio_general = mysqli_fetch_assoc(mysqli_query($conexion, "SELECT AVG(nota) as p FROM notas"))['p'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Administrador — José Antonio Galán</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
<?php
// Contar solicitudes pendientes
$sql_pendientes = "SELECT COUNT(*) as t FROM recuperacion_password WHERE estado='pendiente'";
$total_pendientes = mysqli_fetch_assoc(mysqli_query($conexion, $sql_pendientes))['t'];
?>

<nav class="navbar navbar-dark" style="background: linear-gradient(135deg, #1e293b, #0f172a);">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="#">
            <img src="../assets/logo.png" alt="Logo"> Colegio José Antonio Galán
        </a>
        <div class="ms-auto d-flex align-items-center gap-3">

            <!-- Notificaciones sistema -->
            <a href="admin_solicitudes.php" class="btn btn-outline-light btn-sm position-relative">
                🔑
                <?php if ($total_pendientes > 0): ?>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        <?= $total_pendientes ?>
                    </span>
                <?php endif; ?>
            </a>

            <span class="text-white small">⚙️ <?= $_SESSION['nombre'] ?></span>
            <a href="../cerrar_sesion.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-4">

    <div class="mb-4">
        <h4 class="fw-bold">Panel de Administración ⚙️</h4>
        <p class="text-muted">Control total del sistema — <?= date('d/m/Y') ?></p>
    </div>

    <!-- Tarjetas resumen -->
    <div class="row g-3 mb-4">
        <div class="col-md-2">
            <div class="card text-center shadow-sm border-0 p-3">
                <div class="fs-1">🎓</div>
                <h3 class="fw-bold text-primary"><?= $total_estudiantes ?></h3>
                <small class="text-muted">Estudiantes</small>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card text-center shadow-sm border-0 p-3">
                <div class="fs-1">👨‍🏫</div>
                <h3 class="fw-bold text-success"><?= $total_profesores ?></h3>
                <small class="text-muted">Profesores</small>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card text-center shadow-sm border-0 p-3">
                <div class="fs-1">📊</div>
                <h3 class="fw-bold text-info"><?= $total_notas ?></h3>
                <small class="text-muted">Notas</small>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card text-center shadow-sm border-0 p-3">
                <div class="fs-1">📋</div>
                <h3 class="fw-bold text-warning"><?= $total_formativos ?></h3>
                <small class="text-muted">Formativos</small>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card text-center shadow-sm border-0 p-3">
                <div class="fs-1">📁</div>
                <h3 class="fw-bold text-danger"><?= $total_actividades ?></h3>
                <small class="text-muted">Actividades</small>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card text-center shadow-sm border-0 p-3">
                <div class="fs-1">📈</div>
                <h3 class="fw-bold <?= ($promedio_general ?? 0) >= 6 ? 'text-success' : 'text-danger' ?>">
                    <?= $promedio_general ? round($promedio_general, 1) : '—' ?>
                </h3>
                <small class="text-muted">Promedio</small>
            </div>
        </div>
    </div>

    <!-- Módulos -->
    <h5 class="fw-bold mb-3">Módulos de Administración</h5>
    <div class="row g-4">
        <div class="col-md-3">
            <div class="card text-center shadow-sm h-100 p-2">
                <div class="card-body">
                    <div class="fs-1 mb-2">👥</div>
                    <h5 class="fw-bold">Usuarios</h5>
                    <p class="text-muted small">Gestionar estudiantes y profesores</p>
                    <a href="admin_usuarios.php" class="btn btn-primary btn-sm w-100">Gestionar</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm h-100 p-2">
                <div class="card-body">
                    <div class="fs-1 mb-2">📊</div>
                    <h5 class="fw-bold">Notas</h5>
                    <p class="text-muted small">Ver y modificar todas las notas</p>
                    <a href="admin_notas.php" class="btn btn-info btn-sm w-100">Gestionar</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm h-100 p-2">
                <div class="card-body">
                    <div class="fs-1 mb-2">🔔</div>
                    <h5 class="fw-bold">Notificaciones</h5>
                    <p class="text-muted small">Enviar avisos a usuarios</p>
                    <a href="admin_notificaciones.php" class="btn btn-warning btn-sm w-100">Enviar</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm h-100 p-2">
                <div class="card-body">
                    <div class="fs-1 mb-2">📋</div>
                    <h5 class="fw-bold">Formativos</h5>
                    <p class="text-muted small">Ver todos los formativos</p>
                    <a href="admin_formativos.php" class="btn btn-danger btn-sm w-100">Ver</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/asistente.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>