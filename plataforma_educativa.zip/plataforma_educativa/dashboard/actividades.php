<?php
session_start();
include '../includes/conexion.php';
 include '../includes/asistente.php'; 
if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'profesor') {
    header("Location: ../index.php");
    exit();
}

$profesor_id = $_SESSION['id'];
$mensaje = "";
$error = "";

// Subir actividad
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'crear') {
    $titulo = $_POST['titulo'];
    $descripcion = $_POST['descripcion'];
    $materia_id = $_POST['materia_id'];
    $fecha_limite = $_POST['fecha_limite'];
    $archivo = "";

    if (isset($_FILES['archivo']) && $_FILES['archivo']['error'] == 0) {
        $ext = pathinfo($_FILES['archivo']['name'], PATHINFO_EXTENSION);
        $permitidos = ['pdf', 'docx', 'jpg', 'jpeg', 'png'];
        if (in_array(strtolower($ext), $permitidos)) {
            $nombre_archivo = time() . '_' . $_FILES['archivo']['name'];
            $ruta = "../uploads/actividades/" . $nombre_archivo;
            move_uploaded_file($_FILES['archivo']['tmp_name'], $ruta);
            $archivo = $nombre_archivo;
        } else {
            $error = "❌ Tipo de archivo no permitido";
        }
    }

    if (!$error) {
        $sql = "INSERT INTO actividades (profesor_id, materia_id, titulo, descripcion, archivo, fecha_limite) 
                VALUES ($profesor_id, $materia_id, '$titulo', '$descripcion', '$archivo', '$fecha_limite')";

        if (mysqli_query($conexion, $sql)) {
            $actividad_id = mysqli_insert_id($conexion);

            // Obtener grado de la materia
            $sql_mat = "SELECT grado FROM materias WHERE id=$materia_id";
            $res_mat = mysqli_query($conexion, $sql_mat);
            $mat = mysqli_fetch_assoc($res_mat);
            $grado = $mat['grado'];

            // Notificar a todos los estudiantes del grado
            $sql_ests = "SELECT id FROM usuarios WHERE rol='estudiante' AND grado='$grado'";
            $res_ests = mysqli_query($conexion, $sql_ests);
            while ($est = mysqli_fetch_assoc($res_ests)) {
                $sql_notif = "INSERT INTO notificaciones (usuario_id, titulo, mensaje, tipo) 
                              VALUES ({$est['id']}, 'Nueva actividad publicada', 
                              'Se publicó una nueva actividad: $titulo', 'actividad')";
                mysqli_query($conexion, $sql_notif);
            }
            $mensaje = "✅ Actividad publicada correctamente";
        } else {
            $error = "❌ Error al publicar la actividad";
        }
    }
}

// Calificar entrega
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'calificar') {
    $entrega_id = $_POST['entrega_id'];
    $calificacion = $_POST['calificacion'];

    $sql = "UPDATE entregas SET calificacion=$calificacion, estado='entregado' WHERE id=$entrega_id";
    if (mysqli_query($conexion, $sql)) {
        $mensaje = "✅ Calificación guardada correctamente";
    } else {
        $error = "❌ Error al guardar calificación";
    }
}

// Materias del profesor
$sql_materias = "SELECT m.id, m.nombre, m.grado FROM materias m
                 JOIN profesor_materias pm ON m.id = pm.materia_id
                 WHERE pm.profesor_id = $profesor_id ORDER BY m.grado, m.nombre";
$materias = mysqli_query($conexion, $sql_materias);

// Actividades del profesor
$grado_filtro = isset($_GET['grado']) ? $_GET['grado'] : '';
if ($grado_filtro) {
    $sql_actividades = "SELECT a.*, m.nombre as materia, m.grado FROM actividades a
                        JOIN materias m ON a.materia_id = m.id
                        WHERE a.profesor_id=$profesor_id AND m.grado='$grado_filtro'
                        ORDER BY a.created_at DESC";
} else {
    $sql_actividades = "SELECT a.*, m.nombre as materia, m.grado FROM actividades a
                        JOIN materias m ON a.materia_id = m.id
                        WHERE a.profesor_id=$profesor_id
                        ORDER BY a.created_at DESC";
}
$actividades = mysqli_query($conexion, $sql_actividades);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actividades</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<nav class="navbar navbar-dark bg-primary">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="profesor.php">
            <img src="../assets/logo.png" alt="Logo"> Colegio José Antonio Galán
        </a>
        <div class="ms-auto d-flex gap-2">
            <a href="profesor.php" class="btn btn-outline-light btn-sm">⬅ Volver</a>
            <a href="../cerrar_sesion.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h4 class="fw-bold mb-4">📁 Gestión de Actividades</h4>

    <?php if ($mensaje): ?>
        <div class="alert alert-success"><?= $mensaje ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <!-- Tabs -->
    <ul class="nav nav-tabs mb-4">
        <li class="nav-item">
            <a class="nav-link active" data-bs-toggle="tab" href="#publicar">📤 Publicar Actividad</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#lista">📋 Mis Actividades</a>
        </li>
    </ul>

    <div class="tab-content">

        <!-- Tab publicar -->
        <div class="tab-pane fade show active" id="publicar">
            <div class="card shadow-sm">
                <div class="card-header bg-info text-white fw-bold">📤 Nueva Actividad</div>
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="accion" value="crear">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Título</label>
                                <input type="text" name="titulo" class="form-control" 
                                       placeholder="Título de la actividad" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Materia</label>
                                <select name="materia_id" class="form-select" required>
                                    <option value="">Seleccionar...</option>
                                    <?php while ($m = mysqli_fetch_assoc($materias)): ?>
                                        <option value="<?= $m['id'] ?>">
                                            <?= $m['nombre'] ?> (<?= $m['grado'] ?>)
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Fecha límite</label>
                                <input type="date" name="fecha_limite" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Archivo (opcional)</label>
                                <input type="file" name="archivo" class="form-control" 
                                       accept=".pdf,.docx,.jpg,.jpeg,.png">
                                <small class="text-muted">PDF, Word o imágenes</small>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold">Descripción</label>
                                <textarea name="descripcion" class="form-control" rows="3" 
                                          placeholder="Describe la actividad..." required></textarea>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-info mt-3 text-white">
                            📤 Publicar Actividad
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Tab lista actividades -->
        <div class="tab-pane fade" id="lista">

            <!-- Filtro por grado -->
            <form method="GET" class="mb-3">
                <div class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <select name="grado" class="form-select" onchange="this.form.submit()">
                            <option value="">Todos los grados</option>
                            <option value="Grado 6"  <?= $grado_filtro=='Grado 6'  ? 'selected' : '' ?>>Grado 6</option>
                            <option value="Grado 7"  <?= $grado_filtro=='Grado 7'  ? 'selected' : '' ?>>Grado 7</option>
                            <option value="Grado 8"  <?= $grado_filtro=='Grado 8'  ? 'selected' : '' ?>>Grado 8</option>
                            <option value="Grado 9"  <?= $grado_filtro=='Grado 9'  ? 'selected' : '' ?>>Grado 9</option>
                            <option value="Grado 10" <?= $grado_filtro=='Grado 10' ? 'selected' : '' ?>>Grado 10</option>
                            <option value="Grado 11" <?= $grado_filtro=='Grado 11' ? 'selected' : '' ?>>Grado 11</option>
                        </select>
                    </div>
                </div>
            </form>

            <?php while ($a = mysqli_fetch_assoc($actividades)): 
                // Contar entregas
                $sql_ent = "SELECT COUNT(*) as total FROM entregas WHERE actividad_id={$a['id']}";
                $res_ent = mysqli_query($conexion, $sql_ent);
                $total_entregas = mysqli_fetch_assoc($res_ent)['total'];

                $vencida = strtotime($a['fecha_limite']) < time();
            ?>
            <div class="card shadow-sm mb-3 border-0">
                <div class="card-header d-flex justify-content-between align-items-center
                    <?= $vencida ? 'bg-danger' : 'bg-info' ?> text-white">
                    <strong>📁 <?= $a['titulo'] ?></strong>
                    <span class="badge bg-white <?= $vencida ? 'text-danger' : 'text-info' ?>">
                        <?= $vencida ? '⏰ Vencida' : '✅ Activa' ?>
                    </span>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <p class="mb-1"><?= $a['descripcion'] ?></p>
                            <small class="text-muted">
                                📚 <?= $a['materia'] ?> — 🎓 <?= $a['grado'] ?> — 
                                📅 Límite: <?= date('d/m/Y', strtotime($a['fecha_limite'])) ?>
                            </small>
                            <?php if ($a['archivo']): ?>
                                <br><a href="../uploads/actividades/<?= $a['archivo'] ?>" 
                                       target="_blank" class="btn btn-sm btn-outline-info mt-2">
                                    📎 Ver archivo
                                </a>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-4 text-end">
                            <span class="badge bg-secondary fs-6">
                                📬 <?= $total_entregas ?> entregas
                            </span>
                            <br>
                            <a href="ver_entregas.php?id=<?= $a['id'] ?>" 
                               class="btn btn-sm btn-outline-primary mt-2">
                                Ver entregas
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>