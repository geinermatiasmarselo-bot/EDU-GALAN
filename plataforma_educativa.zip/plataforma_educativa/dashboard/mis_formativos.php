<?php
session_start();
include '../includes/conexion.php';
 include '../includes/asistente.php';
if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'estudiante') {
    header("Location: ../index.php");
    exit();
}

$estudiante_id = $_SESSION['id'];

// Datos del estudiante
$sql_est = "SELECT * FROM usuarios WHERE id=$estudiante_id";
$res_est = mysqli_query($conexion, $sql_est);
$estudiante = mysqli_fetch_assoc($res_est);

// Formativos del estudiante
$sql_formativos = "SELECT f.*, u.nombre as profesor FROM formativos f
                   JOIN usuarios u ON f.profesor_id = u.id
                   WHERE f.estudiante_id = $estudiante_id
                   ORDER BY f.fecha DESC";
$formativos = mysqli_query($conexion, $sql_formativos);

// Conteo por tipo
$sql_conteo = "SELECT 
    SUM(CASE WHEN tipo='llamado_escrito' THEN 1 ELSE 0 END) as llamados,
    SUM(CASE WHEN tipo='citacion_padres' THEN 1 ELSE 0 END) as citaciones,
    SUM(CASE WHEN tipo='suspension' THEN 1 ELSE 0 END) as suspensiones,
    COUNT(*) as total
    FROM formativos WHERE estudiante_id=$estudiante_id";
$res_conteo = mysqli_query($conexion, $sql_conteo);
$conteo = mysqli_fetch_assoc($res_conteo);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Formativos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<nav class="navbar navbar-dark bg-success">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="estudiante.php">
            <img src="../assets/logo.png" alt="Logo"> Colegio José Antonio Galán
        </a>
        <div class="ms-auto d-flex gap-2">
            <a href="estudiante.php" class="btn btn-outline-light btn-sm">⬅ Volver</a>
            <a href="../cerrar_sesion.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-4">

    <!-- Info estudiante -->
    <div class="card shadow-sm mb-4 border-0">
        <div class="card-body d-flex align-items-center gap-3">
            <div class="fs-1">👤</div>
            <div>
                <h4 class="mb-0 fw-bold"><?= $estudiante['nombre'] ?></h4>
                <span class="badge bg-success"><?= $estudiante['grado'] ?></span>
            </div>
        </div>
    </div>

    <h4 class="fw-bold mb-4">📋 Mis Formativos</h4>

    <!-- Tarjetas resumen -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card text-center shadow-sm border-0 p-2">
                <div class="fs-1">📋</div>
                <h3 class="fw-bold text-secondary"><?= $conteo['total'] ?? 0 ?></h3>
                <small class="text-muted">Total</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm border-0 p-2">
                <div class="fs-1">⚠️</div>
                <h3 class="fw-bold text-warning"><?= $conteo['llamados'] ?? 0 ?></h3>
                <small class="text-muted">Llamados escritos</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm border-0 p-2">
                <div class="fs-1">👨‍👩‍👧</div>
                <h3 class="fw-bold text-info"><?= $conteo['citaciones'] ?? 0 ?></h3>
                <small class="text-muted">Citaciones</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm border-0 p-2">
                <div class="fs-1">🚫</div>
                <h3 class="fw-bold text-danger"><?= $conteo['suspensiones'] ?? 0 ?></h3>
                <small class="text-muted">Suspensiones</small>
            </div>
        </div>
    </div>

    <!-- Lista de formativos -->
    <?php if (mysqli_num_rows($formativos) == 0): ?>
        <div class="alert alert-info">📭 No tienes formativos registrados.</div>
    <?php else: ?>
        <?php while ($f = mysqli_fetch_assoc($formativos)):
            $color = match($f['tipo']) {
                'llamado_escrito' => 'warning',
                'citacion_padres' => 'info',
                'suspension'      => 'danger',
                default           => 'secondary'
            };
            $tipo_texto = match($f['tipo']) {
                'llamado_escrito' => '⚠️ Llamado Escrito',
                'citacion_padres' => '👨‍👩‍👧 Citación a Padres',
                'suspension'      => '🚫 Suspensión',
                default           => $f['tipo']
            };
        ?>
        <div class="card mb-3 border-0 shadow-sm border-start border-<?= $color ?> border-4">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <span class="badge bg-<?= $color ?> <?= $color == 'warning' ? 'text-dark' : '' ?> fs-6">
                        <?= $tipo_texto ?>
                    </span>
                    <small class="text-muted"><?= date('d/m/Y', strtotime($f['fecha'])) ?></small>
                </div>
                <p class="mb-2"><?= $f['descripcion'] ?></p>
                <div class="d-flex justify-content-between align-items-center">
                    <small class="text-muted">Registrado por: <strong><?= $f['profesor'] ?></strong></small>
                    <div>
                        <?php if ($f['afecta_nota'] > 0): ?>
                            <span class="badge bg-danger me-2">⚠️ Afecta nota: -<?= $f['afecta_nota'] ?></span>
                        <?php endif; ?>
                        <span class="badge <?= $f['firmado'] == 'firmado' ? 'bg-success' : 'bg-secondary' ?>">
                            <?= $f['firmado'] == 'firmado' ? '✅ Firmado' : '⏳ Pendiente firma' ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    <?php endif; ?>
</div>

</body>
</html>