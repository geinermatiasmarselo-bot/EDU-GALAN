<?php
session_start();
include '../includes/conexion.php';
 include '../includes/asistente.php';
if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'profesor') {
    header("Location: ../index.php");
    exit();
}

$estudiante_id = $_GET['id'];

// Datos del estudiante
$sql_est = "SELECT * FROM usuarios WHERE id=$estudiante_id AND rol='estudiante'";
$res_est = mysqli_query($conexion, $sql_est);
$estudiante = mysqli_fetch_assoc($res_est);

if (!$estudiante) {
    header("Location: notas.php");
    exit();
}

// Notas del estudiante
$sql_notas = "SELECT n.*, m.nombre as materia FROM notas n
              JOIN materias m ON n.materia_id = m.id
              WHERE n.estudiante_id = $estudiante_id
              ORDER BY n.periodo, m.nombre";
$notas = mysqli_query($conexion, $sql_notas);

$notas_por_periodo = [];
while ($n = mysqli_fetch_assoc($notas)) {
    $notas_por_periodo[$n['periodo']][] = $n;
}

// Formativos del estudiante
$sql_formativos = "SELECT f.*, u.nombre as profesor FROM formativos f
                   JOIN usuarios u ON f.profesor_id = u.id
                   WHERE f.estudiante_id = $estudiante_id
                   ORDER BY f.fecha DESC";
$formativos = mysqli_query($conexion, $sql_formativos);

// Asistencia resumen
$sql_asist = "SELECT 
    SUM(CASE WHEN estado='presente' THEN 1 ELSE 0 END) as presentes,
    SUM(CASE WHEN estado='ausente' THEN 1 ELSE 0 END) as ausentes,
    SUM(CASE WHEN estado='tardanza' THEN 1 ELSE 0 END) as tardanzas,
    COUNT(*) as total
    FROM asistencia WHERE estudiante_id=$estudiante_id";
$res_asist = mysqli_query($conexion, $sql_asist);
$asistencia = mysqli_fetch_assoc($res_asist);

// Promedio general
$sql_prom = "SELECT AVG(nota) as promedio FROM notas WHERE estudiante_id=$estudiante_id";
$res_prom = mysqli_query($conexion, $sql_prom);
$promedio = mysqli_fetch_assoc($res_prom)['promedio'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil Estudiante</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<nav class="navbar navbar-dark bg-primary">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="profesor.php">
            <img src="../assets/logo.png" alt="Logo"> Colegio José Antonio Galán
        </a>
        <div class="ms-auto d-flex gap-2">
            <a href="notas.php" class="btn btn-outline-light btn-sm">⬅ Volver</a>
            <a href="../cerrar_sesion.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-4">

    <!-- Info principal estudiante -->
    <div class="card shadow-sm mb-4 border-0">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="d-flex align-items-center gap-3 mb-3">
                        <div class="fs-1">👤</div>
                        <div>
                            <h4 class="mb-0 fw-bold"><?= $estudiante['nombre'] ?></h4>
                            <span class="badge bg-primary"><?= $estudiante['grado'] ?></span>
                        </div>
                    </div>
                    <table class="table table-sm">
                        <tr>
                            <td class="text-muted fw-semibold">📧 Correo</td>
                            <td><?= $estudiante['email'] ?></td>
                        </tr>
                        <tr>
                            <td class="text-muted fw-semibold">🪪 T.I.</td>
                            <td><?= $estudiante['tarjeta_identidad'] ?? '—' ?></td>
                        </tr>
                        <tr>
                            <td class="text-muted fw-semibold">📱 Teléfono</td>
                            <td><?= $estudiante['telefono_estudiante'] ?? '—' ?></td>
                        </tr>
                        <tr>
                            <td class="text-muted fw-semibold">🏠 Dirección</td>
                            <td><?= $estudiante['direccion'] ?? '—' ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <h6 class="fw-bold text-primary mb-3">👨‍👩‍👧 Acudientes</h6>
                    <table class="table table-sm">
                        <tr>
                            <td class="text-muted fw-semibold">Acudiente 1</td>
                            <td><?= $estudiante['nombre_acudiente1'] ?? '—' ?></td>
                            <td><?= $estudiante['telefono_acudiente1'] ?? '—' ?></td>
                        </tr>
                        <tr>
                            <td class="text-muted fw-semibold">Acudiente 2</td>
                            <td><?= $estudiante['nombre_acudiente2'] ?? '—' ?></td>
                            <td><?= $estudiante['telefono_acudiente2'] ?? '—' ?></td>
                        </tr>
                    </table>

                    <!-- Resumen académico -->
                    <h6 class="fw-bold text-primary mb-3 mt-3">📊 Resumen Académico</h6>
                    <div class="row g-2">
                        <div class="col-6">
                            <div class="card text-center p-2 border-0 bg-light">
                                <h4 class="fw-bold <?= ($promedio ?? 0) >= 6 ? 'text-success' : 'text-danger' ?>">
                                    <?= $promedio ? round($promedio, 1) : '—' ?>
                                </h4>
                                <small class="text-muted">Promedio general</small>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card text-center p-2 border-0 bg-light">
                                <h4 class="fw-bold text-danger"><?= $asistencia['ausentes'] ?? 0 ?></h4>
                                <small class="text-muted">Ausencias</small>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card text-center p-2 border-0 bg-light">
                                <h4 class="fw-bold text-success"><?= $asistencia['presentes'] ?? 0 ?></h4>
                                <small class="text-muted">Presentes</small>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card text-center p-2 border-0 bg-light">
                                <h4 class="fw-bold text-warning"><?= $asistencia['tardanzas'] ?? 0 ?></h4>
                                <small class="text-muted">Tardanzas</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabs -->
    <ul class="nav nav-tabs mb-4">
        <li class="nav-item">
            <a class="nav-link active" data-bs-toggle="tab" href="#notas">📊 Notas</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#formativos">📋 Formativos</a>
        </li>
    </ul>

    <div class="tab-content">

        <!-- Tab Notas -->
        <div class="tab-pane fade show active" id="notas">
            <?php if (empty($notas_por_periodo)): ?>
                <p class="text-muted text-center">Sin notas registradas</p>
            <?php else: ?>
                <ul class="nav nav-pills mb-3">
                    <?php $primero = true; foreach ($notas_por_periodo as $periodo => $notas): ?>
                        <li class="nav-item">
                            <a class="nav-link <?= $primero ? 'active' : '' ?>"
                               data-bs-toggle="tab"
                               href="#periodo_<?= str_replace(' ', '_', $periodo) ?>">
                                <?= $periodo ?>
                            </a>
                        </li>
                    <?php $primero = false; endforeach; ?>
                </ul>
                <div class="tab-content">
                    <?php $primero = true; foreach ($notas_por_periodo as $periodo => $notas): ?>
                        <div class="tab-pane fade <?= $primero ? 'show active' : '' ?>"
                             id="periodo_<?= str_replace(' ', '_', $periodo) ?>">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead class="table-dark">
                                        <tr>
                                            <th>Materia</th>
                                            <th>Nota</th>
                                            <th>Observación</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $suma = 0; $cantidad = 0;
                                        foreach ($notas as $n):
                                            $suma += $n['nota']; $cantidad++;
                                        ?>
                                        <tr>
                                            <td><?= $n['materia'] ?></td>
                                            <td>
                                                <span class="badge fs-6 <?= $n['nota'] >= 6 ? 'bg-success' : 'bg-danger' ?>">
                                                    <?= $n['nota'] ?>
                                                </span>
                                            </td>
                                            <td><?= $n['observacion'] ?? '-' ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                    <tfoot>
                                        <tr class="table-secondary">
                                            <td><strong>Promedio</strong></td>
                                            <td colspan="2">
                                                <?php $prom = round($suma/$cantidad, 2); ?>
                                                <span class="badge fs-6 <?= $prom >= 6 ? 'bg-success' : 'bg-danger' ?>">
                                                    <?= $prom ?>
                                                </span>
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    <?php $primero = false; endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Tab Formativos -->
        <div class="tab-pane fade" id="formativos">
            <?php
            $tiene_formativos = false;
            while ($f = mysqli_fetch_assoc($formativos)):
                $tiene_formativos = true;
                $color = match($f['tipo']) {
                    'llamado_escrito' => 'warning',
                    'citacion_padres' => 'info',
                    'suspension'      => 'danger',
                    default           => 'secondary'
                };
                $tipo_texto = match($f['tipo']) {
                    'llamado_escrito' => 'Llamado Escrito',
                    'citacion_padres' => 'Citación a Padres',
                    'suspension'      => 'Suspensión',
                    default           => $f['tipo']
                };
            ?>
                <div class="card mb-3 border-0 shadow-sm">
                    <div class="card-header bg-<?= $color ?> <?= $color == 'warning' ? 'text-dark' : 'text-white' ?> d-flex justify-content-between rounded-top">
                        <strong><?= $tipo_texto ?></strong>
                        <span><?= date('d/m/Y', strtotime($f['fecha'])) ?></span>
                    </div>
                    <div class="card-body">
                        <p><?= $f['descripcion'] ?></p>
                        <small class="text-muted">Registrado por: <strong><?= $f['profesor'] ?></strong></small>
                        <?php if ($f['afecta_nota'] > 0): ?>
                            <br><small class="text-danger">⚠️ Afecta nota: -<?= $f['afecta_nota'] ?> puntos</small>
                        <?php endif; ?>
                        <br>
                        <span class="badge <?= $f['firmado'] == 'firmado' ? 'bg-success' : 'bg-secondary' ?> mt-1">
                            <?= $f['firmado'] == 'firmado' ? '✅ Firmado' : '⏳ Pendiente firma' ?>
                        </span>
                    </div>
                </div>
            <?php endwhile; ?>
            <?php if (!$tiene_formativos): ?>
                <p class="text-muted text-center">Sin formativos registrados</p>
            <?php endif; ?>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>