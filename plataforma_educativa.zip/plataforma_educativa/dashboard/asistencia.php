<?php
session_start();
include '../includes/conexion.php';
 include '../includes/asistente.php';
if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'profesor') {
    header("Location: ../index.php");
    exit();
}

$profesor_id = $_SESSION['id'];
$mensaje = "";

// Guardar asistencia
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fecha = $_POST['fecha'];

    foreach ($_POST['asistencia'] as $estudiante_id => $estado) {
        $verificar = "SELECT id FROM asistencia WHERE estudiante_id=$estudiante_id AND fecha='$fecha'";
        $res = mysqli_query($conexion, $verificar);

        if (mysqli_num_rows($res) > 0) {
            $sql = "UPDATE asistencia SET estado='$estado' WHERE estudiante_id=$estudiante_id AND fecha='$fecha'";
        } else {
            $sql = "INSERT INTO asistencia (estudiante_id, curso_id, fecha, estado) 
                    VALUES ($estudiante_id, 1, '$fecha', '$estado')";
        }
        mysqli_query($conexion, $sql);
    }
    $mensaje = "✅ Asistencia guardada correctamente";
}

// Filtros
$grado_filtro = isset($_GET['grado']) ? $_GET['grado'] : '';
$fecha_filtro = isset($_GET['fecha']) ? $_GET['fecha'] : date('Y-m-d');

if ($grado_filtro) {
    $sql_estudiantes = "SELECT id, nombre, grado FROM usuarios 
                        WHERE rol='estudiante' AND grado='$grado_filtro' 
                        ORDER BY nombre";
} else {
    $sql_estudiantes = "SELECT id, nombre, grado FROM usuarios 
                        WHERE rol='estudiante' 
                        ORDER BY nombre";
}
$estudiantes = mysqli_query($conexion, $sql_estudiantes);

// Resumen de asistencia del grado seleccionado
$resumen = [];
if ($grado_filtro) {
    $sql_resumen = "SELECT u.nombre, 
                    SUM(CASE WHEN a.estado='presente' THEN 1 ELSE 0 END) as presentes,
                    SUM(CASE WHEN a.estado='ausente' THEN 1 ELSE 0 END) as ausentes,
                    SUM(CASE WHEN a.estado='tardanza' THEN 1 ELSE 0 END) as tardanzas
                    FROM usuarios u
                    LEFT JOIN asistencia a ON u.id = a.estudiante_id
                    WHERE u.rol='estudiante' AND u.grado='$grado_filtro'
                    GROUP BY u.id, u.nombre";
    $res_resumen = mysqli_query($conexion, $sql_resumen);
    while ($r = mysqli_fetch_assoc($res_resumen)) {
        $resumen[] = $r;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asistencia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<nav class="navbar navbar-dark bg-success">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="profesor.php">🏫 Plataforma Educativa</a>
        <div class="ms-auto d-flex gap-2">
            <a href="profesor.php" class="btn btn-outline-light btn-sm">⬅ Volver</a>
            <a href="../cerrar_sesion.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h4 class="mb-4">✅ Tomar Asistencia</h4>

    <?php if ($mensaje): ?>
        <div class="alert alert-success"><?= $mensaje ?></div>
    <?php endif; ?>

    <!-- Filtros -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-secondary text-white">🎓 Seleccionar Grado y Fecha</div>
        <div class="card-body">
            <form method="GET">
                <div class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label class="form-label">Grado</label>
                        <select name="grado" class="form-select" onchange="this.form.submit()">
                            <option value="">Selecciona un grado</option>
                            <option value="Grado 6"  <?= $grado_filtro=='Grado 6'  ? 'selected' : '' ?>>Grado 6</option>
                            <option value="Grado 7"  <?= $grado_filtro=='Grado 7'  ? 'selected' : '' ?>>Grado 7</option>
                            <option value="Grado 8"  <?= $grado_filtro=='Grado 8'  ? 'selected' : '' ?>>Grado 8</option>
                            <option value="Grado 9"  <?= $grado_filtro=='Grado 9'  ? 'selected' : '' ?>>Grado 9</option>
                            <option value="Grado 10" <?= $grado_filtro=='Grado 10' ? 'selected' : '' ?>>Grado 10</option>
                            <option value="Grado 11" <?= $grado_filtro=='Grado 11' ? 'selected' : '' ?>>Grado 11</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Fecha</label>
                        <input type="date" name="fecha" class="form-control" 
                               value="<?= $fecha_filtro ?>" onchange="this.form.submit()">
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php if ($grado_filtro): ?>

    <!-- Tabs -->
    <ul class="nav nav-tabs mb-4">
        <li class="nav-item">
            <a class="nav-link active" data-bs-toggle="tab" href="#tomar">📋 Tomar Asistencia</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#resumen">📊 Resumen General</a>
        </li>
    </ul>

    <div class="tab-content">

        <!-- Tab tomar asistencia -->
        <div class="tab-pane fade show active" id="tomar">
            <form method="POST">
                <input type="hidden" name="fecha" value="<?= $fecha_filtro ?>">
                <div class="card shadow-sm">
                    <div class="card-header bg-success text-white">
                        📋 <?= $grado_filtro ?> — <?= date('d/m/Y', strtotime($fecha_filtro)) ?>
                    </div>
                    <div class="card-body table-responsive">
                        <table class="table table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>Estudiante</th>
                                    <th class="text-center text-success">✅ Presente</th>
                                    <th class="text-center text-danger">❌ Ausente</th>
                                    <th class="text-center text-warning">⏰ Tardanza</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $hay_estudiantes = false;
                                while ($e = mysqli_fetch_assoc($estudiantes)):
                                    $hay_estudiantes = true;
                                    $sql_check = "SELECT estado FROM asistencia 
                                                  WHERE estudiante_id={$e['id']} AND fecha='$fecha_filtro'";
                                    $res_check = mysqli_query($conexion, $sql_check);
                                    $reg = mysqli_fetch_assoc($res_check);
                                    $estado_actual = $reg ? $reg['estado'] : 'presente';
                                ?>
                                <tr>
                                    <td><strong><?= $e['nombre'] ?></strong></td>
                                    <td class="text-center">
                                        <input type="radio" name="asistencia[<?= $e['id'] ?>]" 
                                               value="presente" class="form-check-input"
                                               <?= $estado_actual == 'presente' ? 'checked' : '' ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="radio" name="asistencia[<?= $e['id'] ?>]" 
                                               value="ausente" class="form-check-input"
                                               <?= $estado_actual == 'ausente' ? 'checked' : '' ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="radio" name="asistencia[<?= $e['id'] ?>]" 
                                               value="tardanza" class="form-check-input"
                                               <?= $estado_actual == 'tardanza' ? 'checked' : '' ?>>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                                <?php if (!$hay_estudiantes): ?>
                                    <tr>
                                        <td colspan="4" class="text-center text-muted">
                                            No hay estudiantes en este grado
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php if ($hay_estudiantes): ?>
                    <button type="submit" class="btn btn-success mt-3 w-100">
                        💾 Guardar Asistencia
                    </button>
                <?php endif; ?>
            </form>
        </div>

        <!-- Tab resumen -->
        <div class="tab-pane fade" id="resumen">
            <div class="card shadow-sm">
                <div class="card-header bg-secondary text-white">
                    📊 Resumen de Asistencia — <?= $grado_filtro ?>
                </div>
                <div class="card-body table-responsive">
                    <table class="table table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Estudiante</th>
                                <th class="text-center text-success">Presentes</th>
                                <th class="text-center text-danger">Ausentes</th>
                                <th class="text-center text-warning">Tardanzas</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($resumen as $r): ?>
                                <tr>
                                    <td><?= $r['nombre'] ?></td>
                                    <td class="text-center">
                                        <span class="badge bg-success"><?= $r['presentes'] ?></span>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge bg-danger"><?= $r['ausentes'] ?></span>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge bg-warning text-dark"><?= $r['tardanzas'] ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

    <?php else: ?>
        <div class="alert alert-info">👆 Selecciona un grado para tomar asistencia</div>
    <?php endif; ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>