<?php
session_start();
include '../includes/conexion.php';
include '../includes/asistente.php';

if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'estudiante') {
    header("Location: ../index.php");
    exit();
}

$estudiante_id = $_SESSION['id'];

// Datos del estudiante
$sql_est = "SELECT * FROM usuarios WHERE id=$estudiante_id";
$res_est = mysqli_query($conexion, $sql_est);
$estudiante = mysqli_fetch_assoc($res_est);

// Notas agrupadas por periodo
$sql_notas = "SELECT n.*, m.nombre as materia FROM notas n
              JOIN materias m ON n.materia_id = m.id
              WHERE n.estudiante_id = $estudiante_id
              ORDER BY n.periodo, m.nombre";
$res_notas = mysqli_query($conexion, $sql_notas);

$notas_por_periodo = [];
$notas_por_materia = [];

while ($n = mysqli_fetch_assoc($res_notas)) {
    $notas_por_periodo[$n['periodo']][] = $n;
    $notas_por_materia[$n['materia']][] = $n;
}

// Promedio general
$sql_prom = "SELECT AVG(nota) as promedio FROM notas WHERE estudiante_id=$estudiante_id";
$res_prom = mysqli_query($conexion, $sql_prom);
$promedio_general = mysqli_fetch_assoc($res_prom)['promedio'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Notas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/estilos.css">
    <style>
        .badge-periodo {
            font-size: 0.9rem;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-dark bg-success">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="estudiante.php">
            <img src="../assets/logo.png" alt="Logo"> Colegio José Antonio Galán
        </a>
        <div class="ms-auto d-flex gap-2">
            <a href="estudiante.php" class="btn btn-outline-light btn-sm">⬅ Volver</a>
            <a href="../cerrar_sesion.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <!-- Info estudiante -->
    <div class="card shadow-sm mb-4 border-0">
        <div class="card-body d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center gap-3">
                <div class="fs-1">👤</div>
                <div>
                    <h4 class="mb-0 fw-bold"><?= htmlspecialchars($estudiante['nombre']) ?></h4>
                    <span class="badge bg-success"><?= $estudiante['grado'] ?></span>
                </div>
            </div>
            <div class="text-center">
                <h3 class="mb-0 fw-bold <?= ($promedio_general ?? 0) >= 6 ? 'text-success' : 'text-danger' ?>">
                    <?= $promedio_general ? round($promedio_general, 1) : '—' ?>
                </h3>
                <small class="text-muted">Promedio general</small>
            </div>
        </div>
    </div>

    <h4 class="mb-4 fw-bold">📊 Mis Notas</h4>

    <?php if (empty($notas_por_periodo)): ?>
        <div class="alert alert-info">📭 Aún no tienes notas registradas.</div>
    <?php else: ?>
        <!-- Tabs principales -->
        <ul class="nav nav-tabs mb-4">
            <li class="nav-item">
                <a class="nav-link active" data-bs-toggle="tab" href="#por_periodo">📅 Por Periodo</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#por_materia">📚 Por Materia</a>
            </li>
        </ul>

        <div class="tab-content">
            <!-- TAB POR PERIODO -->
            <div class="tab-pane fade show active" id="por_periodo">
                <?php 
                $periodos = ['Periodo 1', 'Periodo 2', 'Periodo 3', 'Periodo 4'];
                $hay_notas = false;
                ?>
                <ul class="nav nav-pills mb-3">
                    <?php foreach ($periodos as $index => $periodo): ?>
                        <?php if (isset($notas_por_periodo[$periodo])): $hay_notas = true; ?>
                            <li class="nav-item">
                                <a class="nav-link <?= $index === 0 ? 'active' : '' ?>" 
                                   data-bs-toggle="tab" 
                                   href="#periodo_<?= str_replace(' ', '_', $periodo) ?>">
                                    <?= $periodo ?>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </ul>

                <div class="tab-content">
                    <?php foreach ($periodos as $index => $periodo): ?>
                        <?php if (isset($notas_por_periodo[$periodo])): ?>
                            <div class="tab-pane fade <?= $index === 0 ? 'show active' : '' ?>" 
                                 id="periodo_<?= str_replace(' ', '_', $periodo) ?>">
                                <div class="card shadow-sm">
                                    <div class="card-body table-responsive">
                                        <table class="table table-hover">
                                            <thead class="table-dark">
                                                <tr>
                                                    <th>Materia</th>
                                                    <th>Nota</th>
                                                    <th>Observación</th>
                                                    <th>Fecha</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                $suma = 0; $cantidad = 0;
                                                foreach ($notas_por_periodo[$periodo] as $n):
                                                    $suma += $n['nota']; $cantidad++;
                                                ?>
                                                    <tr>
                                                        <td><?= htmlspecialchars($n['materia']) ?></td>
                                                        <td>
                                                            <span class="badge fs-6 <?= $n['nota'] >= 6 ? 'bg-success' : 'bg-danger' ?>">
                                                                <?= $n['nota'] ?>
                                                            </span>
                                                        </td>
                                                        <td><?= htmlspecialchars($n['observacion'] ?? '-') ?></td>
                                                        <td><?= date('d/m/Y', strtotime($n['created_at'])) ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                            <tfoot>
                                                <tr class="table-secondary">
                                                    <td><strong>Promedio del periodo</strong></td>
                                                    <td colspan="3">
                                                        <?php $promedio = round($suma / $cantidad, 2); ?>
                                                        <span class="badge fs-6 <?= $promedio >= 6 ? 'bg-success' : 'bg-danger' ?>">
                                                            <?= $promedio ?>
                                                        </span>
                                                    </td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
                <?php if (!$hay_notas): ?>
                    <div class="alert alert-info">No hay notas registradas en ningún periodo.</div>
                <?php endif; ?>
            </div>

            <!-- TAB POR MATERIA -->
            <div class="tab-pane fade" id="por_materia">
                <div class="row g-4">
                    <?php foreach ($notas_por_materia as $materia => $notas): 
                        $suma = array_sum(array_column($notas, 'nota'));
                        $promedio_mat = round($suma / count($notas), 2);
                    ?>
                        <div class="col-md-6">
                            <div class="card shadow-sm">
                                <div class="card-header d-flex justify-content-between align-items-center
                                    <?= $promedio_mat >= 6 ? 'bg-success' : 'bg-danger' ?> text-white">
                                    <strong>📚 <?= htmlspecialchars($materia) ?></strong>
                                    <span class="badge bg-white <?= $promedio_mat >= 6 ? 'text-success' : 'text-danger' ?> fs-6">
                                        Prom: <?= $promedio_mat ?>
                                    </span>
                                </div>
                                <div class="card-body table-responsive">
                                    <table class="table table-sm table-hover mb-0">
                                        <thead class="table-dark">
                                            <tr>
                                                <th>Periodo</th>
                                                <th>Nota</th>
                                                <th>Observación</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($notas as $n): 
                                                $color_periodo = [
                                                    'Periodo 1' => 'primary',
                                                    'Periodo 2' => 'success',
                                                    'Periodo 3' => 'warning',
                                                    'Periodo 4' => 'danger'
                                                ];
                                                $color = $color_periodo[$n['periodo']] ?? 'secondary';
                                            ?>
                                                <tr>
                                                    <td>
                                                        <span class="badge bg-<?= $color ?> badge-periodo">
                                                            <?= $n['periodo'] ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <span class="badge <?= $n['nota'] >= 6 ? 'bg-success' : 'bg-danger' ?>">
                                                            <?= $n['nota'] ?>
                                                        </span>
                                                    </td>
                                                    <td><?= htmlspecialchars($n['observacion'] ?? '-') ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>